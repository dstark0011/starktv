const { app, BrowserWindow, ipcMain, shell, safeStorage, session, Menu, screen } = require('electron');
const http = require('http');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

// Many IPTV panels only answer player-style user agents
app.userAgentFallback = 'VLC/3.0.20 LibVLC/3.0.20';
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

/* ---------- small JSON files in %APPDATA%\Tidewatch IPTV (folder name kept from before the rename to StarkTV) ---------- */
// keep using the old settings folder so saved logins, favourites and history carry over after the rename
app.setPath('userData', path.join(app.getPath('appData'), 'Tidewatch IPTV'));
const dataFile = name => path.join(app.getPath('userData'), name);
function readJson(name, dflt) { try { return JSON.parse(fs.readFileSync(dataFile(name), 'utf8')); } catch { return dflt; } }
function writeJson(name, obj) {
  const f = dataFile(name), tmp = f + '.tmp';
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, f);
}

// Passwords / M3U links are encrypted with Windows DPAPI (tied to your Windows login)
function enc(s) {
  if (!s) return '';
  if (safeStorage.isEncryptionAvailable()) return 'enc:' + safeStorage.encryptString(s).toString('base64');
  return 'b64:' + Buffer.from(s, 'utf8').toString('base64');
}
function dec(s) {
  if (!s) return '';
  if (s.startsWith('enc:')) { try { return safeStorage.decryptString(Buffer.from(s.slice(4), 'base64')); } catch { return ''; } }
  if (s.startsWith('b64:')) return Buffer.from(s.slice(4), 'base64').toString('utf8');
  return s;
}

ipcMain.on('profiles-load', e => {
  const d = readJson('profiles.json', null);
  e.returnValue = d ? { ...d, profiles: (d.profiles || []).map(p => ({ ...p, pass: dec(p.pass), m3u: dec(p.m3u) })) } : null;
});
ipcMain.on('profiles-save', (e, d) => {
  try {
    writeJson('profiles.json', { ...d, profiles: (d.profiles || []).map(p => ({ ...p, pass: enc(p.pass), m3u: enc(p.m3u) })) });
    e.returnValue = true;
  } catch { e.returnValue = false; }
});

// native right-click menu (resolves with the chosen id, or null)
ipcMain.handle('ctx-menu', (e, items) => new Promise(res => {
  let done = false; const finish = v => { if (!done) { done = true; res(v); } };
  const menu = Menu.buildFromTemplate(items.map(i => i.sep ? { type: 'separator' } : { label: i.label, click: () => finish(i.id) }));
  menu.popup({ window: BrowserWindow.fromWebContents(e.sender), callback: () => setTimeout(() => finish(null), 100) });
}));
// error log next to the .exe (and in AppData) so problems can be diagnosed
ipcMain.on('log', (_e, line) => {
  const txt = `${new Date().toISOString()} ${line}\n`;
  for (const f of [path.join(path.dirname(process.execPath), 'starktv-log.txt'), dataFile('starktv-log.txt')]) { try { fs.appendFileSync(f, txt); } catch {} }
});

let mainWin = null;
function createWindow() {
  const b = readJson('window.json', {});
  const win = mainWin = new BrowserWindow({
    width: b.width || 1400, height: b.height || 860, x: b.x, y: b.y, minWidth: 1000, minHeight: 600,
    backgroundColor: '#13202b',
    icon: path.join(__dirname, 'starktv.png'),
    autoHideMenuBar: true,
    title: 'StarkTV v' + app.getVersion().replace(/\.0$/, ''),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: false,          // panels rarely send CORS headers
      allowRunningInsecureContent: true,
      backgroundThrottling: false, // keep streams fed when the window isn't focused
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  if (b.max) win.maximize();
  win.webContents.on('console-message', (_e, level, message, line, src) => { if (level >= 3) ipcMain.emit('log', null, `console: ${message} (${path.basename(src || '')}:${line})`); });
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  for (const ev of ['move', 'resize', 'maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen']) win.on(ev, () => vlcPlace());
  win.on('minimize', () => vlcHost.send('hide'));
  win.on('restore', () => { if (vlcState.visible) vlcHost.send('show'); vlcPlace(); });
  win.on('close', () => {
    try { writeJson('window.json', { ...win.getNormalBounds(), max: win.isMaximized() }); } catch {}
  });
}

const playerCandidates = () => {
  const pf = process.env['ProgramFiles'] || 'C:\\Program Files';
  const pf86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  return [
    path.join(pf, 'VideoLAN', 'VLC', 'vlc.exe'),
    path.join(pf86, 'VideoLAN', 'VLC', 'vlc.exe'),
    path.join(pf, 'mpv', 'mpv.exe'),
    path.join(process.env.LOCALAPPDATA || '', 'Programs', 'mpv', 'mpv.exe')
  ];
};

const findPlayer = custom => (custom ? [custom, ...playerCandidates()] : playerCandidates()).find(p => p && fs.existsSync(p));
const mainLog = line => { const txt = `${new Date().toISOString()} ${line}\n`; for (const f of [path.join(path.dirname(process.execPath), 'starktv-log.txt'), dataFile('starktv-log.txt')]) { try { fs.appendFileSync(f, txt); } catch {} } };

// no VLC on this PC → install it with Windows' own package manager (winget), straight from VideoLAN
let vlcInstall = null;
function installVlc() {
  if (vlcInstall) return vlcInstall;
  vlcInstall = new Promise(res => {
    let out = '';
    const p = spawn('winget', ['install', '--exact', '--id', 'VideoLAN.VLC', '--source', 'winget', '--silent',
      '--accept-package-agreements', '--accept-source-agreements', '--disable-interactivity'], { windowsHide: true });
    p.stdout.on('data', d => { out += d; }); p.stderr.on('data', d => { out += d; });
    p.on('error', e => res({ ok: false, why: 'winget not available (' + e.message + ')' }));
    p.on('close', code => res({ ok: !!findPlayer(''), why: `winget exit ${code}: ${out.replace(/\s+/g, ' ').slice(-300)}` }));
  }).then(r => { mainLog('vlc install: ' + (r.ok ? 'ok' : r.why)); return r; }).finally(() => { vlcInstall = null; });
  return vlcInstall;
}

ipcMain.handle('open-external-player', async (e, url, title, custom) => {
  let exe = findPlayer(custom), installed = false;
  if (!exe) {
    try { e.sender.send('player-status', 'VLC isn’t installed – installing it now (first time only, about a minute)…'); } catch {}
    await installVlc();
    exe = findPlayer(custom); installed = !!exe;
    if (!exe) {
      shell.openExternal('https://www.videolan.org/vlc/');
      return { ok: false, error: 'Couldn’t install VLC automatically, so the VLC download page has opened in your browser. Install it, then press “Open in VLC” again.' };
    }
  }
  const isVlc = exe.toLowerCase().includes('vlc');
  const args = isVlc
    ? [url, `--meta-title=${title || ''}`, '--network-caching=3000']
    : [url, `--title=${title || ''}`, '--cache=yes', '--demuxer-max-bytes=150MiB'];
  spawn(exe, args, { detached: true, stdio: 'ignore' }).unref();
  return { ok: true, player: path.basename(exe), installed };
});

/* ---------- Embedded VLC ----------
   VLC runs hidden in the background and draws into a borderless native window (vlchost.ps1) that sits exactly
   over StarkTV's player area. StarkTV controls it through VLC's local web interface (127.0.0.1 only, random password). */
const vlcState = { proc: null, port: 0, pass: '', hwnd: 0, rect: null, visible: false, poll: null, starting: null, wantShow: false };
const vlcHost = {
  proc: null, ready: null,
  start() {
    if (this.ready) return this.ready;
    this.ready = new Promise((res, rej) => {
      const owner = mainWin ? mainWin.getNativeWindowHandle().readBigInt64LE(0).toString() : '0';
      const p = this.proc = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-STA', '-WindowStyle', 'Hidden',
        '-File', path.join(__dirname, 'vlchost.ps1'), '-Owner', owner], { windowsHide: true });
      let buf = '';
      p.stdout.on('data', d => {
        buf += d; let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          if (line.startsWith('HWND ')) res(+line.slice(5));
          else if (line === 'activated') { try { mainWin?.focus(); } catch {} }
          else if (line === 'dblclick') { try { mainWin?.webContents.send('vlc-event', 'dblclick'); } catch {} }
        }
      });
      p.stderr.on('data', d => mainLog('vlchost: ' + String(d).trim().slice(0, 300)));
      p.on('exit', () => { this.proc = null; this.ready = null; });
      p.on('error', e => rej(e));
      setTimeout(() => rej(new Error('video window did not start')), 15000);
    });
    this.ready.catch(() => { this.ready = null; });
    return this.ready;
  },
  send(cmd) { try { this.proc?.stdin.write(cmd + '\n'); } catch {} }
};
function vlcPlace() {
  if (!mainWin || !vlcState.rect || !vlcHost.proc) return;
  const cb = mainWin.getContentBounds(), r = vlcState.rect;
  const s = screen.dipToScreenRect(mainWin, { x: Math.round(cb.x + r.x), y: Math.round(cb.y + r.y), width: Math.max(1, Math.round(r.w)), height: Math.max(1, Math.round(r.h)) });
  vlcHost.send(`bounds ${s.x} ${s.y} ${s.width} ${s.height}`);
}
function vlcReq(query) {
  return new Promise(res => {
    const req = http.get({ host: '127.0.0.1', port: vlcState.port, path: '/requests/status.json' + (query ? '?' + query : ''),
      headers: { Authorization: 'Basic ' + Buffer.from(':' + vlcState.pass).toString('base64') }, timeout: 3000 }, r => {
      let d = ''; r.on('data', c => { d += c; }); r.on('end', () => { try { res(JSON.parse(d)); } catch { res(null); } });
    });
    req.on('error', () => res(null)); req.on('timeout', () => { req.destroy(); res(null); });
  });
}
async function vlcStart() {
  if (vlcState.proc) return true;
  if (vlcState.starting) return vlcState.starting;
  vlcState.starting = (async () => {
    let exe = findPlayer('');
    if (!exe || !/vlc/i.test(exe)) { await installVlc(); exe = findPlayer(''); }
    if (!exe || !/vlc/i.test(exe)) throw new Error('VLC isn’t installed and couldn’t be installed automatically.');
    const hwnd = await vlcHost.start();
    vlcState.port = 40000 + Math.floor(Math.random() * 9000);
    vlcState.pass = require('crypto').randomBytes(12).toString('hex');
    const p = vlcState.proc = spawn(exe, ['--intf', 'dummy', '--dummy-quiet', '--extraintf', 'http', '--http-host', '127.0.0.1',
      '--http-port', String(vlcState.port), '--http-password', vlcState.pass, `--drawable-hwnd=${hwnd}`,
      '--no-video-title-show', '--no-osd', '--no-snapshot-preview', '--no-qt-error-dialogs', '--no-mouse-events', '--no-keyboard-events',
      '--network-caching=2000', '--live-caching=2000', '--http-reconnect', '--no-random', '--no-loop', '--no-repeat', '--quiet'],
      { windowsHide: true, stdio: 'ignore' });
    p.on('exit', code => { mainLog('vlc exited ' + code); vlcState.proc = null; vlcHost.send('hide'); vlcState.visible = false; try { mainWin?.webContents.send('vlc-state', { state: 'exited' }); } catch {} });
    for (let i = 0; i < 40; i++) { if (await vlcReq('')) return true; await new Promise(r => setTimeout(r, 250)); }
    throw new Error('VLC started but isn’t answering');
  })().finally(() => { vlcState.starting = null; });
  return vlcState.starting;
}
function vlcPollStart() {
  clearInterval(vlcState.poll);
  vlcState.poll = setInterval(async () => {
    const s = await vlcReq(''); if (!s) return;
    const playing = s.state === 'playing' || s.state === 'paused';
    if (playing && vlcState.wantShow && !vlcState.visible) { vlcState.visible = true; vlcPlace(); vlcHost.send('show'); }
    try { mainWin?.webContents.send('vlc-state', { state: s.state, volume: s.volume, time: s.time, length: s.length }); } catch {}
  }, 700);
}
ipcMain.handle('vlc-play', async (_e, url) => {
  try {
    await vlcStart();
    vlcState.wantShow = true;
    await vlcReq('command=in_play&input=' + encodeURIComponent(url));
    vlcPollStart();
    return { ok: true };
  } catch (err) { mainLog('vlc-play: ' + err.message); return { ok: false, error: err.message }; }
});
ipcMain.handle('vlc-stop', async () => {
  vlcState.wantShow = false; vlcState.visible = false; vlcHost.send('hide'); clearInterval(vlcState.poll);
  if (vlcState.proc) await vlcReq('command=pl_stop');
  return true;
});
ipcMain.handle('vlc-cmd', async (_e, q) => (vlcState.proc ? vlcReq(q) : null));
ipcMain.on('vlc-bounds', (_e, r) => { vlcState.rect = r; vlcPlace(); });
ipcMain.on('vlc-visible', (_e, v) => {           // the page hides the video window while a dialog is open over it
  if (!vlcState.wantShow) return;
  vlcState.visible = !!v; vlcHost.send(v ? 'show' : 'hide'); if (v) vlcPlace();
});
app.on('will-quit', () => { try { vlcState.proc?.kill(); } catch {} vlcHost.send('exit'); try { vlcHost.proc?.kill(); } catch {} });

app.whenReady().then(createWindow);
// make sure favourites / column widths in localStorage hit disk before exit
app.on('before-quit', () => { try { session.defaultSession.flushStorageData(); } catch {} });
app.on('window-all-closed', () => app.quit());
