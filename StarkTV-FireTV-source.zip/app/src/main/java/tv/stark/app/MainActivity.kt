package tv.stark.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.hls.DefaultHlsExtractorFactory
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.ui.PlayerView
import org.json.JSONObject
import java.io.File

/**
 * StarkTV for Android TV / Fire TV.
 * The interface is the same HTML/JS app as the PC version (in assets/web), running in a WebView.
 * Video plays in a native Media3 (ExoPlayer) view laid over the page's player area, or full screen.
 */
@OptIn(UnstableApi::class)
class MainActivity : Activity() {

    companion object {
        const val UA = "VLC/3.0.20 LibVLC/3.0.20"    // many IPTV panels only answer player-style user agents
        const val BG = "#13202b"
        const val MATCH = FrameLayout.LayoutParams.MATCH_PARENT
    }

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var playerView: PlayerView
    private var player: ExoPlayer? = null
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("starktv", Context.MODE_PRIVATE) }

    private var fullscreen = false
    private var wantVisible = false
    private var currentUrl: String? = null
    private var retries = 0
    private var bounds: JSONObject? = null
    private var lastBack = 0L
    @Volatile private var lastStatus = "{\"state\":\"idle\"}"

    // live timeshift (safety delay, pause, rewind, fast-forward)
    @Volatile private var recorder: TimeshiftRecorder? = null
    private var recGen = 0
    private var delayMs = 15000L            // Settings → Live delay
    private var keepMs = 30 * 60_000L       // Settings → Pause & rewind up to
    private var trick = 0                   // <0 rewinding, >0 fast-forwarding (×speed)
    private var playHeldDown = 0L
    private var playLongDone = false
    private val usingTimeshift get() = recorder != null

    private val isLive: Boolean
        get() {
            val u = currentUrl ?: return false
            return !(u.contains("/movie/") || u.contains("/series/") ||
                Regex("\\.(mp4|mkv|avi|mov|webm|m4v)(\\?|$)", RegexOption.IGNORE_CASE).containsMatchIn(u))
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor(BG))

        WebView.setWebContentsDebuggingEnabled(true)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor(BG))
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true
        @Suppress("DEPRECATION")
        s.allowFileAccessFromFileURLs = true
        @Suppress("DEPRECATION")
        s.allowUniversalAccessFromFileURLs = true     // the page talks to your provider directly, like the PC app
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.mediaPlaybackRequiresUserGesture = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.userAgentString = UA
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) log("console: ${m.message()} (${m.sourceId()}:${m.lineNumber()})")
                return true
            }
        }

        playerView = PlayerView(this)
        playerView.setBackgroundColor(Color.BLACK)
        playerView.useController = false
        playerView.isFocusable = false
        playerView.keepScreenOn = true
        playerView.visibility = View.GONE

        root.addView(web, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(playerView, FrameLayout.LayoutParams(1, 1))
        setContentView(root)

        web.requestFocus()
        web.loadUrl("file:///android_asset/web/index.html")
    }

    /* ---------------- player ---------------- */

    private fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
        val extractors = DefaultExtractorsFactory()
            .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES)
        // platform decoders first; FFmpeg steps in for audio the TV can't decode (MP2, AC-3 on some boxes…)
        val renderers = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http, extractors))
            .build()
        p.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
        )
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) retries = 0
                if (state == Player.STATE_ENDED && isLive) reconnect("stream ended")
                sendState()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) = sendState()

            override fun onPlayerError(error: PlaybackException) {
                log("player error: ${error.errorCodeName} ${error.message} ${error.cause?.message ?: ""}")
                val p = player
                if (usingTimeshift && p != null && retries < 6) {
                    // paused/rewound past the kept window, or a segment just rolled out: carry on from live
                    retries++
                    trickStop(resume = false)
                    p.seekToDefaultPosition(); p.prepare(); p.playWhenReady = true
                    return
                }
                val code = (error.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode ?: 0
                if (currentUrl != null && retries < (if (code == 469) 4 else 3)) reconnect(error.errorCodeName)
                else sendState("error", friendly(error, code))
            }
        })
        playerView.player = p
        player = p
        return p
    }

    private fun startUrl(url: String) {
        val p = ensurePlayer()
        stopRecorder()
        trickStop(resume = false)
        if (isLive && !url.contains(".m3u8")) { startTimeshift(url); return }
        p.setMediaItem(MediaItem.fromUri(url))
        p.prepare()
        p.playWhenReady = true
    }

    /* ---------------- live timeshift ---------------- */

    private fun startTimeshift(url: String) {
        val gen = ++recGen
        val rec = TimeshiftRecorder(url, UA, File(cacheDir, "timeshift"), keepMs) { log(it) }
        recorder = rec
        rec.start()
        sendState("buffering")
        // wait for the first segment, then hand the playlist to the player
        val waitStart = System.currentTimeMillis()
        val check = object : Runnable {
            override fun run() {
                if (gen != recGen || recorder !== rec) return
                if (rec.segmentCount() >= 1) { playTimeshift(rec, gen); return }
                if (System.currentTimeMillis() - waitStart > 20000) {
                    val code = rec.lastHttpCode
                    sendState("error", if (code != 200 && code != 0) friendlyCode(code) else "This channel isn't sending a picture right now.")
                    return
                }
                main.postDelayed(this, 150)
            }
        }
        main.post(check)
    }

    private fun playTimeshift(rec: TimeshiftRecorder, gen: Int) {
        val p = ensurePlayer()
        val live = MediaItem.LiveConfiguration.Builder()
            .setTargetOffsetMs(maxOf(delayMs, 3000L))
            .setMinOffsetMs(1500)
            .setMinPlaybackSpeed(0.97f)            // builds the safety delay by playing at 97 %
            .setMaxPlaybackSpeed(if (delayMs <= 3000L) 1.03f else 1.0f)
            .build()
        val item = MediaItem.Builder()
            .setUri("http://starktv.timeshift/$gen/index.m3u8")
            .setMimeType(MimeTypes.APPLICATION_M3U8)
            .setLiveConfiguration(live)
            .build()
        val dsf = DataSource.Factory { TimeshiftDataSource { if (recGen == gen) recorder else null } }
        val source = HlsMediaSource.Factory(dsf)
            .setExtractorFactory(DefaultHlsExtractorFactory(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES, true))
            .createMediaSource(item)
        p.setMediaSource(source)
        p.prepare()
        p.playWhenReady = true
        val health = object : Runnable {
            override fun run() {
                if (gen != recGen || recorder !== rec) return
                if (rec.silentForMs() > 25000 && trick == 0 && (player?.playbackState == Player.STATE_BUFFERING)) {
                    val code = rec.lastHttpCode
                    sendState("error", if (code != 200 && code != 0) friendlyCode(code) else "The channel stopped sending – reconnecting…")
                }
                main.postDelayed(this, 3000)
            }
        }
        main.postDelayed(health, 5000)
    }

    private fun stopRecorder() {
        recorder?.stop()
        recorder = null
        recGen++
    }

    /** ms behind real live, or -1 if unknown */
    private fun behindMs(): Long {
        val p = player ?: return -1
        val off = p.currentLiveOffset
        return if (off == C.TIME_UNSET) -1 else off
    }

    /* ---------------- pause / rewind / fast-forward ---------------- */

    private val SPEEDS = intArrayOf(2, 6, 12, 30)

    private val trickTick = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (trick == 0) return
            val step = trick * 500L
            val dur = p.duration
            var target = p.currentPosition + step
            if (target <= 0L) { p.seekTo(0); trickStop(resume = true); return }
            if (trick > 0 && dur != C.TIME_UNSET && target >= dur - maxOf(delayMs, 3000L)) {
                trickStop(resume = false); p.seekToDefaultPosition(); p.playWhenReady = true; sendState(); return
            }
            if (dur != C.TIME_UNSET && target > dur) target = dur
            p.seekTo(target)
            sendState()
            main.postDelayed(this, 500)
        }
    }

    private fun trickPress(forward: Boolean) {
        val p = player ?: return
        if (!usingTimeshift && isLive) return
        val dir = if (forward) 1 else -1
        val cur = if (trick != 0 && Integer.signum(trick) == dir) SPEEDS.indexOf(Math.abs(trick)) else -1
        val next = SPEEDS[minOf(cur + 1, SPEEDS.size - 1)]
        if (forward && behindMs() in 0..(maxOf(delayMs, 3000L) + 1500L) && trick == 0) return   // already at live
        trick = dir * next
        p.setSeekParameters(SeekParameters.CLOSEST_SYNC)
        p.playWhenReady = false
        main.removeCallbacks(trickTick)
        main.post(trickTick)
        sendState()
    }

    private fun trickStop(resume: Boolean) {
        if (trick == 0) return
        trick = 0
        main.removeCallbacks(trickTick)
        player?.let { it.setSeekParameters(SeekParameters.DEFAULT); if (resume) it.playWhenReady = true }
        sendState()
    }

    private fun jump(ms: Long) {
        val p = player ?: return
        trickStop(resume = false)
        val dur = p.duration
        var t = p.currentPosition + ms
        if (t < 0) t = 0
        if (dur != C.TIME_UNSET && t > dur - 1500) { p.seekToDefaultPosition(); return }
        p.seekTo(t)
        sendState()
    }

    private fun goLive() {
        trickStop(resume = false)
        player?.let { it.seekToDefaultPosition(); it.playWhenReady = true }
        sendState()
    }

    private fun togglePause() {
        if (trick != 0) { trickStop(resume = true); return }
        player?.let { it.playWhenReady = !it.playWhenReady }
        sendState()
    }

    private fun reconnect(why: String) {
        val url = currentUrl ?: return
        retries++
        log("reconnecting ($retries): $why")
        sendState("buffering")
        main.postDelayed({ if (currentUrl == url) startUrl(url) }, 1500L * retries)
    }

    private fun friendlyCode(code: Int): String = when (code) {
        469 -> "Your provider refused the stream (469 – all connections on your account are in use). Stop it on other devices, or wait a minute."
        401, 403 -> "Your provider refused the stream ($code). Check your subscription."
        404 -> "This channel isn't available right now (404)."
        else -> "Your provider replied $code."
    }

    private fun friendly(e: PlaybackException, code: Int): String = when {
        code == 469 -> "Your provider refused the stream (469 – all connections on your account are in use). Stop it on other devices, or wait a minute."
        code == 401 || code == 403 -> "Your provider refused the stream ($code). Check your subscription."
        code == 404 -> "This channel isn't available right now (404)."
        code > 0 -> "Your provider replied $code."
        e.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED -> "Can't reach your provider – check the internet connection."
        e.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> "This channel uses a format the TV can't play."
        else -> "Can't play this channel (${e.errorCodeName})."
    }

    private fun stopPlayback() {
        stopRecorder()
        trickStop(resume = false)
        currentUrl = null
        wantVisible = false
        player?.stop()
        player?.clearMediaItems()
        playerView.visibility = View.GONE
        setFull(false)
        sendState("idle")
    }

    private fun layoutPlayer() {
        val lp = playerView.layoutParams as FrameLayout.LayoutParams
        if (fullscreen) {
            lp.width = MATCH; lp.height = MATCH; lp.leftMargin = 0; lp.topMargin = 0
        } else {
            val b = bounds ?: return
            val vw = b.optDouble("vw", 0.0)
            val scale = if (vw > 0 && web.width > 0) web.width / vw else resources.displayMetrics.density.toDouble()
            lp.leftMargin = (b.optDouble("x") * scale).toInt()
            lp.topMargin = (b.optDouble("y") * scale).toInt()
            lp.width = maxOf(1, (b.optDouble("w") * scale).toInt())
            lp.height = maxOf(1, (b.optDouble("h") * scale).toInt())
        }
        playerView.layoutParams = lp
    }

    private fun setFull(on: Boolean) {
        val wasFull = fullscreen
        fullscreen = on
        layoutPlayer()
        val liveFull = on && currentUrl != null && isLive
        playerView.useController = on && currentUrl != null && !isLive     // films/series: play, pause, seek with the remote
        if (liveFull) {
            // video underneath, the page on top with a see-through background so the info banner can be drawn over it
            playerView.isFocusable = false
            web.setBackgroundColor(Color.TRANSPARENT)
            web.bringToFront()
            web.requestFocus()
            js("window.__tvFullMode && window.__tvFullMode(true)")
        } else {
            web.setBackgroundColor(Color.parseColor(BG))
            playerView.bringToFront()
            if (wasFull || !on) js("window.__tvFullMode && window.__tvFullMode(false)")
            if (on) { playerView.isFocusable = true; playerView.requestFocus() }
            else { playerView.hideController(); playerView.isFocusable = false; web.requestFocus() }
        }
        if (!on) trickStop(resume = true)
        sendState()
    }

    private fun sendState(force: String? = null, msg: String? = null) {
        val p = player
        val st = force ?: when {
            p == null || currentUrl == null -> "idle"
            p.playbackState == Player.STATE_BUFFERING -> "buffering"
            p.playbackState == Player.STATE_READY && p.playWhenReady -> "playing"
            p.playbackState == Player.STATE_READY -> "paused"
            p.playbackState == Player.STATE_ENDED -> "ended"
            else -> "buffering"
        }
        val o = JSONObject().put("state", st).put("full", fullscreen).put("live", isLive).put("volume", 256)
            .put("trick", trick).put("paused", p != null && !p.playWhenReady).put("behind", behindMs())
            .put("delay", delayMs).put("timeshift", usingTimeshift)
        if (p != null && usingTimeshift && p.duration != C.TIME_UNSET) o.put("window", p.duration).put("pos", p.currentPosition)
        if (msg != null) o.put("msg", msg)
        p?.let { if (!isLive && it.duration > 0) { o.put("time", it.currentPosition / 1000); o.put("length", it.duration / 1000) } }
        lastStatus = o.toString()
        js("window.__nativeState && window.__nativeState($lastStatus)")
    }

    private fun js(code: String) = main.post { web.evaluateJavascript(code, null) }

    private fun log(line: String) {
        Log.i("StarkTV", line)
        try { File(filesDir, "starktv-log.txt").appendText("${System.currentTimeMillis()} $line\n") } catch (_: Exception) {}
    }

    /* ---------------- remote control ---------------- */

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode
        val down = e.action == KeyEvent.ACTION_DOWN
        val liveFull = fullscreen && isLive && currentUrl != null

        // watching live full screen: the remote drives the info banner and the timeshift
        if (liveFull) {
            when (code) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                    if (down && e.repeatCount == 0) {
                        val up = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_CHANNEL_UP
                        js("window.__tvZap && window.__tvZap(${if (up) -1 else 1})")
                    }
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    if (down && e.repeatCount == 0) js("window.__osdKey && window.__osdKey('ok')")
                    return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    // banner showing: move between its buttons; banner hidden: jump 10 s (the page decides)
                    if (down) js("window.__osdKey && window.__osdKey('${if (code == KeyEvent.KEYCODE_DPAD_LEFT) "left" else "right"}')")
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                    if (down && e.repeatCount == 0) { trickPress(code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD); js("window.__osdShow && window.__osdShow()") }
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                    // tap = play/pause, hold = back to live
                    if (down && e.repeatCount == 0) { playHeldDown = System.currentTimeMillis(); playLongDone = false }
                    else if (down && !playLongDone && System.currentTimeMillis() - playHeldDown > 600) {
                        playLongDone = true; goLive(); js("window.__osdShow && window.__osdShow()")
                    } else if (!down && !playLongDone) { togglePause(); js("window.__osdShow && window.__osdShow()") }
                    return true
                }
                KeyEvent.KEYCODE_BACK -> {
                    if (!down) return true
                    if (trick != 0) { trickStop(resume = true); js("window.__osdShow && window.__osdShow()"); return true }
                    web.evaluateJavascript("(window.__osdBack && window.__osdBack()) ? 1 : 0") { r ->
                        if (r == null || !r.contains("1")) { setFull(false); js("window.__tvAfterFull && window.__tvAfterFull()") }
                    }
                    return true
                }
                KeyEvent.KEYCODE_MENU -> {
                    if (down) js("window.__tvFavCurrent && window.__tvFavCurrent()")
                    return true
                }
            }
            return super.dispatchKeyEvent(e)
        }

        val handled = code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_MENU || code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        if (!handled) return super.dispatchKeyEvent(e)
        if (!down) return true
        when (code) {
            KeyEvent.KEYCODE_BACK -> {
                if (fullscreen) { setFull(false); js("window.__tvAfterFull && window.__tvAfterFull()") }
                else web.evaluateJavascript("(window.__tvBack && window.__tvBack()) ? 1 : 0") { r ->
                    if (r == null || !r.contains("1")) {
                        val now = System.currentTimeMillis()
                        if (now - lastBack < 2500) finish()
                        else { lastBack = now; Toast.makeText(this, "Press Back again to exit StarkTV", Toast.LENGTH_SHORT).show() }
                    }
                }
            }
            KeyEvent.KEYCODE_MENU ->
                if (fullscreen) js("window.__tvFavCurrent && window.__tvFavCurrent()")   // watching: star this channel
                else js("window.__tvMenu && window.__tvMenu()")                            // browsing: menu for the highlighted channel
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> togglePause()
        }
        return true
    }

    /* ---------------- lifecycle ---------------- */

    private var stoppedLive = false

    override fun onPause() {
        super.onPause()
        player?.playWhenReady = false
    }

    override fun onStop() {
        super.onStop()
        if (currentUrl != null && isLive) { stopRecorder(); player?.stop(); stoppedLive = true }   // don't hold a connection in the background
    }

    override fun onResume() {
        super.onResume()
        val url = currentUrl ?: return
        if (isLive) { if (stoppedLive) { stoppedLive = false; startUrl(url) } else player?.playWhenReady = true }
        else player?.playWhenReady = true
    }

    override fun onDestroy() {
        stopRecorder()
        player?.release(); player = null
        web.destroy()
        super.onDestroy()
    }

    /* ---------------- bridge for the page (window.AndroidBridge) ---------------- */

    inner class Bridge {
        @JavascriptInterface fun loadProfiles(): String = prefs.getString("profiles", "") ?: ""
        @JavascriptInterface fun saveProfiles(json: String): Boolean { prefs.edit().putString("profiles", json).apply(); return true }
        @JavascriptInterface fun log(line: String) = this@MainActivity.log(line)
        @JavascriptInterface fun status(): String = lastStatus
        @JavascriptInterface fun version(): String =
            try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Exception) { "" }

        @JavascriptInterface fun play(url: String) = main.post {
            if (url == currentUrl && player != null && (recorder != null || !isLive)) { sendState(); return@post }   // already on it
            currentUrl = url; retries = 0; wantVisible = true
            playerView.visibility = View.VISIBLE
            layoutPlayer()
            startUrl(url)
            if (fullscreen) setFull(true)    // refresh controller for live vs film
        }

        @JavascriptInterface fun stop() = main.post { stopPlayback() }
        @JavascriptInterface fun togglePause() = main.post { this@MainActivity.togglePause() }
        @JavascriptInterface fun goLive() = main.post { this@MainActivity.goLive() }
        @JavascriptInterface fun jumpBy(ms: Int) = main.post { this@MainActivity.jump(ms.toLong()) }
        @JavascriptInterface fun trick(forward: Boolean) = main.post { this@MainActivity.trickPress(forward) }
        @JavascriptInterface fun refreshStatus(): String { main.post { sendState() }; return lastStatus }
        @JavascriptInterface fun setOptions(json: String) = main.post {
            try {
                val o = JSONObject(json)
                delayMs = o.optLong("delay", 15L) * 1000L
                keepMs = maxOf(1L, o.optLong("keepMin", 30L)) * 60_000L
            } catch (_: Exception) {}
        }
        @JavascriptInterface fun setFullscreen(on: Boolean) = main.post { if (currentUrl != null || !on) setFull(on) }
        @JavascriptInterface fun setBounds(json: String) = main.post {
            try { bounds = JSONObject(json); layoutPlayer() } catch (_: Exception) {}
        }
        @JavascriptInterface fun setVisible(v: Boolean) = main.post {
            playerView.visibility = if (v && wantVisible) View.VISIBLE else View.GONE
        }
        @JavascriptInterface fun exitApp() = main.post { finish() }
        @JavascriptInterface fun toast(text: String) = main.post { Toast.makeText(this@MainActivity, text, Toast.LENGTH_SHORT).show() }
    }
}
