package tv.stark.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.ui.PlayerView
import org.json.JSONObject
import java.io.File

/**
 * StarkTV for Android TV / Fire TV.
 * The interface is the same HTML/JS app as the PC version (in assets/web), running in a WebView.
 * Video plays in a native Media3 (ExoPlayer) view laid over the page's player area, or full screen.
 */
@OptIn(UnstableApi::class)
class MainActivity : Activity() {

    companion object {
        const val UA = "VLC/3.0.20 LibVLC/3.0.20"    // many IPTV panels only answer player-style user agents
        const val BG = "#13202b"
        const val MATCH = FrameLayout.LayoutParams.MATCH_PARENT
    }

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var playerView: PlayerView
    private var player: ExoPlayer? = null
    private val main = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("starktv", Context.MODE_PRIVATE) }

    private var fullscreen = false
    private var wantVisible = false
    private var currentUrl: String? = null
    private var retries = 0
    private var bounds: JSONObject? = null
    private var lastBack = 0L
    @Volatile private var lastStatus = "{\"state\":\"idle\"}"

    private val isLive: Boolean
        get() {
            val u = currentUrl ?: return false
            return !(u.contains("/movie/") || u.contains("/series/") ||
                Regex("\\.(mp4|mkv|avi|mov|webm|m4v)(\\?|$)", RegexOption.IGNORE_CASE).containsMatchIn(u))
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor(BG))

        WebView.setWebContentsDebuggingEnabled(true)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor(BG))
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true
        @Suppress("DEPRECATION")
        s.allowFileAccessFromFileURLs = true
        @Suppress("DEPRECATION")
        s.allowUniversalAccessFromFileURLs = true     // the page talks to your provider directly, like the PC app
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.mediaPlaybackRequiresUserGesture = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.userAgentString = UA
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) log("console: ${m.message()} (${m.sourceId()}:${m.lineNumber()})")
                return true
            }
        }

        playerView = PlayerView(this)
        playerView.setBackgroundColor(Color.BLACK)
        playerView.useController = false
        playerView.isFocusable = false
        playerView.keepScreenOn = true
        playerView.visibility = View.GONE

        root.addView(web, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(playerView, FrameLayout.LayoutParams(1, 1))
        setContentView(root)

        web.requestFocus()
        web.loadUrl("file:///android_asset/web/index.html")
    }

    /* ---------------- player ---------------- */

    private fun ensurePlayer(): ExoPlayer {
        player?.let { return it }
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(UA)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
        val extractors = DefaultExtractorsFactory()
            .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES)
        // platform decoders first; FFmpeg steps in for audio the TV can't decode (MP2, AC-3 on some boxes…)
        val renderers = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http, extractors))
            .build()
        p.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
        )
        p.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) retries = 0
                if (state == Player.STATE_ENDED && isLive) reconnect("stream ended")
                sendState()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) = sendState()

            override fun onPlayerError(error: PlaybackException) {
                log("player error: ${error.errorCodeName} ${error.message} ${error.cause?.message ?: ""}")
                val code = (error.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode ?: 0
                if (currentUrl != null && retries < (if (code == 469) 4 else 3)) reconnect(error.errorCodeName)
                else sendState("error", friendly(error, code))
            }
        })
        playerView.player = p
        player = p
        return p
    }

    private fun startUrl(url: String) {
        val p = ensurePlayer()
        p.setMediaItem(MediaItem.fromUri(url))
        p.prepare()
        p.playWhenReady = true
    }

    private fun reconnect(why: String) {
        val url = currentUrl ?: return
        retries++
        log("reconnecting ($retries): $why")
        sendState("buffering")
        main.postDelayed({ if (currentUrl == url) startUrl(url) }, 1500L * retries)
    }

    private fun friendly(e: PlaybackException, code: Int): String = when {
        code == 469 -> "Your provider refused the stream (469 – all connections on your account are in use). Stop it on other devices, or wait a minute."
        code == 401 || code == 403 -> "Your provider refused the stream ($code). Check your subscription."
        code == 404 -> "This channel isn't available right now (404)."
        code > 0 -> "Your provider replied $code."
        e.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED -> "Can't reach your provider – check the internet connection."
        e.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> "This channel uses a format the TV can't play."
        else -> "Can't play this channel (${e.errorCodeName})."
    }

    private fun stopPlayback() {
        currentUrl = null
        wantVisible = false
        player?.stop()
        player?.clearMediaItems()
        playerView.visibility = View.GONE
        setFull(false)
        sendState("idle")
    }

    private fun layoutPlayer() {
        val lp = playerView.layoutParams as FrameLayout.LayoutParams
        if (fullscreen) {
            lp.width = MATCH; lp.height = MATCH; lp.leftMargin = 0; lp.topMargin = 0
        } else {
            val b = bounds ?: return
            val vw = b.optDouble("vw", 0.0)
            val scale = if (vw > 0 && web.width > 0) web.width / vw else resources.displayMetrics.density.toDouble()
            lp.leftMargin = (b.optDouble("x") * scale).toInt()
            lp.topMargin = (b.optDouble("y") * scale).toInt()
            lp.width = maxOf(1, (b.optDouble("w") * scale).toInt())
            lp.height = maxOf(1, (b.optDouble("h") * scale).toInt())
        }
        playerView.layoutParams = lp
    }

    private fun setFull(on: Boolean) {
        fullscreen = on
        layoutPlayer()
        playerView.useController = on && currentUrl != null && !isLive     // films/series: play, pause, seek with the remote
        if (on) {
            playerView.isFocusable = true
            playerView.requestFocus()
        } else {
            playerView.hideController()
            playerView.isFocusable = false
            web.requestFocus()
        }
        sendState()
    }

    private fun sendState(force: String? = null, msg: String? = null) {
        val p = player
        val st = force ?: when {
            p == null || currentUrl == null -> "idle"
            p.playbackState == Player.STATE_BUFFERING -> "buffering"
            p.playbackState == Player.STATE_READY && p.playWhenReady -> "playing"
            p.playbackState == Player.STATE_READY -> "paused"
            p.playbackState == Player.STATE_ENDED -> "ended"
            else -> "buffering"
        }
        val o = JSONObject().put("state", st).put("full", fullscreen).put("live", isLive).put("volume", 256)
        if (msg != null) o.put("msg", msg)
        p?.let { if (!isLive && it.duration > 0) { o.put("time", it.currentPosition / 1000); o.put("length", it.duration / 1000) } }
        lastStatus = o.toString()
        js("window.__nativeState && window.__nativeState($lastStatus)")
    }

    private fun js(code: String) = main.post { web.evaluateJavascript(code, null) }

    private fun log(line: String) {
        Log.i("StarkTV", line)
        try { File(filesDir, "starktv-log.txt").appendText("${System.currentTimeMillis()} $line\n") } catch (_: Exception) {}
    }

    /* ---------------- remote control ---------------- */

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode
        val zapKey = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN ||
            code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_CHANNEL_DOWN
        val handled = code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_MENU ||
            code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || (fullscreen && isLive && (zapKey || code == KeyEvent.KEYCODE_DPAD_CENTER))
        if (!handled) return super.dispatchKeyEvent(e)
        if (e.action != KeyEvent.ACTION_DOWN) return true

        when {
            code == KeyEvent.KEYCODE_BACK -> {
                if (fullscreen) { setFull(false); js("window.__tvAfterFull && window.__tvAfterFull()") }
                else web.evaluateJavascript("(window.__tvBack && window.__tvBack()) ? 1 : 0") { r ->
                    if (r == null || !r.contains("1")) {
                        val now = System.currentTimeMillis()
                        if (now - lastBack < 2500) finish()
                        else { lastBack = now; Toast.makeText(this, "Press Back again to exit StarkTV", Toast.LENGTH_SHORT).show() }
                    }
                }
            }
            code == KeyEvent.KEYCODE_MENU ->
                if (fullscreen) js("window.__tvFavCurrent && window.__tvFavCurrent()")   // watching: star this channel
                else js("window.__tvMenu && window.__tvMenu()")                            // browsing: menu for the highlighted channel
            code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> player?.let { it.playWhenReady = !it.playWhenReady }
            zapKey -> {
                val up = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_CHANNEL_UP
                js("window.__tvZap && window.__tvZap(${if (up) -1 else 1})")
            }
            code == KeyEvent.KEYCODE_DPAD_CENTER -> js("window.__tvInfo && window.__tvInfo()")
        }
        return true
    }

    /* ---------------- lifecycle ---------------- */

    override fun onPause() {
        super.onPause()
        player?.playWhenReady = false
    }

    override fun onResume() {
        super.onResume()
        val url = currentUrl ?: return
        if (isLive) startUrl(url) else player?.playWhenReady = true      // live: jump back to "now"
    }

    override fun onDestroy() {
        player?.release(); player = null
        web.destroy()
        super.onDestroy()
    }

    /* ---------------- bridge for the page (window.AndroidBridge) ---------------- */

    inner class Bridge {
        @JavascriptInterface fun loadProfiles(): String = prefs.getString("profiles", "") ?: ""
        @JavascriptInterface fun saveProfiles(json: String): Boolean { prefs.edit().putString("profiles", json).apply(); return true }
        @JavascriptInterface fun log(line: String) = this@MainActivity.log(line)
        @JavascriptInterface fun status(): String = lastStatus

        @JavascriptInterface fun play(url: String) = main.post {
            currentUrl = url; retries = 0; wantVisible = true
            playerView.visibility = View.VISIBLE
            layoutPlayer()
            startUrl(url)
            if (fullscreen) setFull(true)    // refresh controller for live vs film
        }

        @JavascriptInterface fun stop() = main.post { stopPlayback() }
        @JavascriptInterface fun togglePause() = main.post { player?.let { it.playWhenReady = !it.playWhenReady } }
        @JavascriptInterface fun setFullscreen(on: Boolean) = main.post { if (currentUrl != null || !on) setFull(on) }
        @JavascriptInterface fun setBounds(json: String) = main.post {
            try { bounds = JSONObject(json); layoutPlayer() } catch (_: Exception) {}
        }
        @JavascriptInterface fun setVisible(v: Boolean) = main.post {
            playerView.visibility = if (v && wantVisible) View.VISIBLE else View.GONE
        }
        @JavascriptInterface fun exitApp() = main.post { finish() }
        @JavascriptInterface fun toast(text: String) = main.post { Toast.makeText(this@MainActivity, text, Toast.LENGTH_SHORT).show() }
    }
}
