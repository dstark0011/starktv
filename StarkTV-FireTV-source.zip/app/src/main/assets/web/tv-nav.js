'use strict';
/* Remote-control navigation: the arrow keys move focus to the nearest item in that direction, OK clicks it. */
(() => {
  if (!window.AndroidBridge) return;
  const SEL = [
    'button:not([disabled])', 'input', 'select', '.saved-row',
    '#catList li[data-id]', '#itemList li[data-idx]', '#itemList li[data-prog]', '#itemList li[data-more]',
    '#itemList li[data-allcats]', '#itemList li[data-allprogs]', '.ev-row', '.g-ch', '.g-prog', '.eps li', '.ctx button'
  ].join(',');
  const NATIVE = /^(BUTTON|INPUT|SELECT|A|TEXTAREA)$/;

  function visible(el) {
    if (el.closest('[hidden]') || el.closest('dialog:not([open])')) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2 || r.bottom < 0 || r.right < 0 || r.top > innerHeight || r.left > innerWidth) return false;
    // inside a scroller: must be at least partly within it (the guide grid, lists)
    const sc = el.closest('.list, .g-scroll, .np, .eps');
    if (sc) { const s = sc.getBoundingClientRect(); if (r.bottom < s.top - 1 || r.top > s.bottom + 1 || r.right < s.left || r.left > s.right) return false; }
    return getComputedStyle(el).visibility !== 'hidden';
  }
  function scope() {
    const dlg = document.querySelector('dialog[open]'); if (dlg) return dlg;
    const ctx = document.querySelector('.ctx:not([hidden])'); if (ctx) return ctx;
    return document;
  }
  function candidates() { return [...scope().querySelectorAll(SEL)].filter(visible); }
  function focusEl(el) {
    if (!el) return;
    if (!NATIVE.test(el.tagName) && !el.hasAttribute('tabindex')) el.setAttribute('tabindex', '-1');
    el.focus({ preventScroll: true });
    el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }
  window.__tvFocusDefault = () => {
    const pick = document.querySelector('#gInner .g-row.on .g-ch') || document.querySelector('#itemList li.on')
      || document.querySelector('.main:not([hidden]) .rail-btn.on') || candidates()[0];
    focusEl(pick);
  };

  function move(dir) {
    const cur = document.activeElement && document.activeElement !== document.body ? document.activeElement : null;
    const list = candidates();
    if (!cur || !list.includes(cur)) { window.__tvFocusDefault(); return; }
    const a = cur.getBoundingClientRect(), ax = a.left + a.width / 2, ay = a.top + a.height / 2;
    let best = null, bestScore = Infinity;
    for (const el of list) {
      if (el === cur) continue;
      const b = el.getBoundingClientRect(), bx = b.left + b.width / 2, by = b.top + b.height / 2;
      let main, cross, overlap;
      if (dir === 'left' || dir === 'right') {
        main = dir === 'right' ? b.left - a.right : a.left - b.right;
        if ((dir === 'right' ? bx <= ax + 1 : bx >= ax - 1)) continue;
        overlap = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        cross = overlap > 0 ? 0 : Math.abs(by - ay);
      } else {
        main = dir === 'down' ? b.top - a.bottom : a.top - b.bottom;
        if ((dir === 'down' ? by <= ay + 1 : by >= ay - 1)) continue;
        overlap = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        cross = overlap > 0 ? Math.abs(Math.max(a.left, b.left) - a.left) * 0.1 : Math.abs(bx - ax);
      }
      const score = Math.max(main, -8) + cross * 3;
      if (score < bestScore) { bestScore = score; best = el; }
    }
    if (best) focusEl(best);
    else {                                          // nothing visible that way: scroll the list/grid and try again
      const sc = cur.closest('.list, .g-scroll');
      if (sc) {
        const dy = dir === 'down' ? 200 : dir === 'up' ? -200 : 0, dx = dir === 'right' ? 300 : dir === 'left' ? -300 : 0;
        const before = sc.scrollTop + sc.scrollLeft; sc.scrollBy(dx, dy);
        if (sc.scrollTop + sc.scrollLeft !== before) setTimeout(() => move(dir), 60);
      }
    }
  }

  const DIRS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };
  document.addEventListener('keydown', e => {
    const dir = DIRS[e.key];
    const t = e.target;
    if (dir) {
      // typing in a text box: left/right move the cursor until it reaches the end
      if (t.matches && t.matches('input[type=text], input:not([type]), input[type=password], input[type=search]')) {
        const v = t.value || '', s = t.selectionStart, en = t.selectionEnd;
        if ((dir === 'left' && s > 0) || (dir === 'right' && en < v.length)) return;
      }
      if (t.matches && t.matches('select')) return;
      e.preventDefault(); e.stopPropagation();
      move(dir);
      return;
    }
    if ((e.key === 'Enter' || e.key === ' ') && t && t !== document.body && !NATIVE.test(t.tagName)) {
      e.preventDefault(); t.click();
    }
  }, true);

  // first focus once something is on screen
  const start = () => { if (!document.activeElement || document.activeElement === document.body) window.__tvFocusDefault(); };
  window.addEventListener('load', () => setTimeout(start, 400));
  new MutationObserver(() => { if (!document.activeElement || document.activeElement === document.body) setTimeout(start, 50); })
    .observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden'] });
})();
