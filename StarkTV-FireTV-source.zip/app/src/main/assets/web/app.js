'use strict';
window.addEventListener('error', e => window.native?.log?.(`error: ${e.message} (${(e.filename || '').split('/').pop()}:${e.lineno})`));
window.addEventListener('unhandledrejection', e => window.native?.log?.('rejection: ' + (e.reason?.message || e.reason)));
const $ = s => document.querySelector(s);
const TV = !!window.AndroidBridge;                 // running inside the Android TV / Fire TV app
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};
/* Saved logins: encrypted JSON file via the main process (falls back to localStorage) */
const prof = {
  data: null,
  load() {
    if (this.data) return this.data;
    let d = null;
    try { d = window.native?.loadProfiles?.(); } catch {}
    if (!d) {                                   // first run or old version: migrate from localStorage
      d = { profiles: store.get('profiles', []), last: store.get('last', null), autoConnect: true };
      this.data = d; if (d.profiles.length) this.save(d);
    }
    d.profiles = d.profiles || [];
    return this.data = d;
  },
  save(d = this.data) {
    this.data = d;
    let ok = false; try { ok = window.native?.saveProfiles?.(d); } catch {}
    if (!ok) { store.set('profiles', d.profiles); store.set('last', d.last); }
  }
};
const b64 = s => { try { return decodeURIComponent(escape(atob(s))); } catch { return s || ''; } };

const S = {
  profile: null, section: 'live', catId: null,
  cats: { live: [], movie: [], series: [] },
  items: { live: [], movie: [], series: [] },   // all items per section (loaded lazily for xtream)
  loaded: {}, view: [], shown: 200, current: null,
  settings: { format: 'ts', player: '', hideAdult: false, buffer: 'smooth', resume: true, engine: 'auto', liveDelay: 15, rewindMin: 30, osdTime: 5, ...store.get('settings', {}) }
};
const adultRx = /adult|xxx|18\+|porn/i;

/* ---------- Xtream API ---------- */
function base(p) { return p.server.replace(/\/+$/, ''); }
async function api(action, extra = '') {
  const p = S.profile;
  const url = `${base(p)}/player_api.php?username=${encodeURIComponent(p.user)}&password=${encodeURIComponent(p.pass)}${action ? '&action=' + action : ''}${extra}`;
  const r = await fetch(url);
  if (!r.ok) throw new Error(`Server replied ${r.status}`);
  return r.json();
}
function streamUrl(kind, id, ext) {
  const p = S.profile;
  if (p.type === 'm3u') return id;
  const b = `${base(p)}`, u = encodeURIComponent(p.user), pw = encodeURIComponent(p.pass);
  if (kind === 'live') return `${b}/live/${u}/${pw}/${id}.${S.settings.format}`;
  if (kind === 'movie') return `${b}/movie/${u}/${pw}/${id}.${ext || 'mp4'}`;
  return `${b}/series/${u}/${pw}/${id}.${ext || 'mp4'}`;
}

/* ---------- M3U ---------- */
function parseM3U(text) {
  const out = { live: [], movie: [], series: [] }, groups = { live: new Map(), movie: new Map(), series: new Map() };
  const lines = text.split(/\r?\n/);
  let meta = null, n = 0;
  for (const raw of lines) {
    const l = raw.trim();
    if (l.startsWith('#EXTINF')) {
      const attr = k => (l.match(new RegExp(k + '="([^"]*)"')) || [])[1] || '';
      meta = { name: l.slice(l.lastIndexOf(',') + 1).trim() || attr('tvg-name'), logo: attr('tvg-logo'), group: attr('group-title') || 'Ungrouped', epgId: attr('tvg-id') };
    } else if (l && !l.startsWith('#') && meta) {
      const kind = /\/movie\//.test(l) ? 'movie' : /\/series\//.test(l) ? 'series' : 'live';
      const g = groups[kind];
      if (!g.has(meta.group)) g.set(meta.group, 'g' + g.size);
      out[kind].push({ id: l, name: meta.name, icon: meta.logo, cat: g.get(meta.group), num: ++n, url: l, direct: true });
      meta = null;
    }
  }
  const cats = {};
  for (const k of Object.keys(groups)) cats[k] = [...groups[k]].map(([name, id]) => ({ id, name }));
  return { items: out, cats };
}

/* ---------- Connect ---------- */
async function connect(p) {
  S.profile = p; S.loaded = {}; S.cats = { live: [], movie: [], series: [] }; S.items = { live: [], movie: [], series: [] };
  if (p.type === 'xtream') {
    const info = await api('');
    if (!info.user_info || info.user_info.auth === 0) throw new Error('Login refused. Check the username and password.');
    const ui = info.user_info;
    const exp = ui.exp_date ? new Date(ui.exp_date * 1000).toLocaleDateString('en-GB') : 'never';
    $('#acct').innerHTML = `${esc(p.name)}<br>Status: ${esc(ui.status)}<br>Expires: ${exp}<br>Connections: ${esc(ui.active_cons)}/${esc(ui.max_connections)}`;
  } else {
    const r = await fetch(p.m3u);
    if (!r.ok) throw new Error(`Playlist download failed (${r.status})`);
    const txt = await r.text();
    if (!txt.includes('#EXTINF')) throw new Error('That link did not return an M3U playlist.');
    const parsed = parseM3U(txt);
    S.items = parsed.items; S.cats = parsed.cats; S.loaded = { live: 1, movie: 1, series: 1 };
    $('#acct').innerHTML = `${esc(p.name)}<br>${S.items.live.length} channels`;
  }
  $('#login').hidden = true; $('#main').hidden = false;
  await setSection('guide');
  if (S.settings.resume) { S.startFull = TV; resumeLast(); }
  hideSplash();
}
// start-up screen shown while a saved playlist reconnects, so the login page never flashes up
function hideSplash() { const s = $('#splash'); if (s) s.hidden = true; }
function showLogin() { hideSplash(); $('#main').hidden = true; $('#login').hidden = false; }

/* reopen the last live channel watched on this playlist, with its category selected for zapping */
function resumeLast() {
  const last = store.get('lastLive:' + S.profile.id, null); if (!last) return;
  const it = S.items.live.find(i => i.id === last.id); if (!it) return;
  S.catId = it.cat; renderCats(); renderItems();
  let idx = S.view.findIndex(v => v.id === it.id);
  if (idx < 0) { S.catId = null; renderCats(); renderItems(); idx = S.view.findIndex(v => v.id === it.id); }   // e.g. category now hidden
  if (idx < 0) return;
  if (idx >= S.shown) { S.shown = idx + 100; renderItems(); }
  openItem(S.view[idx]);
  document.querySelector(`#itemList li[data-idx="${idx}"]`)?.scrollIntoView({ block: 'center' });
  document.querySelector(`#gInner .g-row[data-i="${idx}"]`)?.scrollIntoView({ block: 'center', inline: 'nearest' });
  document.querySelector('#catList li.on')?.scrollIntoView({ block: 'center' });
}

async function loadSection(sec) {
  if (S.loaded[sec] || S.profile.type !== 'xtream') return;
  const map = { live: ['get_live_categories', 'get_live_streams'], movie: ['get_vod_categories', 'get_vod_streams'], series: ['get_series_categories', 'get_series'] };
  const [cA, iA] = map[sec];
  const [cats, items] = await Promise.all([api(cA), api(iA)]);
  S.cats[sec] = (cats || []).map(c => ({ id: String(c.category_id), name: c.category_name }));
  S.items[sec] = (items || []).map(i => ({
    id: String(sec === 'series' ? i.series_id : i.stream_id),
    name: i.name, icon: i.stream_icon || i.cover || '', cat: String(i.category_id),
    num: i.num, ext: i.container_extension, epgId: i.epg_channel_id, rating: i.rating
  }));
  S.loaded[sec] = 1;
}

/* ---------- Favourites / recent ---------- */
const favKey = () => 'fav:' + S.profile.id, recKey = () => 'rec:' + S.profile.id;
const favs = () => store.get(favKey(), []);
const isFav = it => favs().some(f => f.kind === it.kind && f.id === it.id);
function toggleFav(it) {
  let f = favs();
  f = isFav(it) ? f.filter(x => !(x.kind === it.kind && x.id === it.id)) : [...f, it];
  store.set(favKey(), f); updateFavBtn();
  if (S.section !== 'guide') keepScroll(renderItems);       // re-drawing the guide would lose your place in it
}
function keepScroll(fn) { const l = $('#itemList'), y = l.scrollTop; fn(); l.scrollTop = y; }
const favData = c => ({ kind: c.kind, id: c.id, name: c.name, icon: c.icon, ext: c.ext, num: c.num, cat: c.cat, url: c.direct ? c.url : undefined, direct: c.direct });
function pushRecent(it) {
  const r = store.get(recKey(), []).filter(x => !(x.kind === it.kind && x.id === it.id));
  r.unshift(it); store.set(recKey(), r.slice(0, 50));
}

/* ---------- Rendering ---------- */
const dsec = () => S.section === 'guide' || S.section === 'search' || S.section === 'live' ? 'live' : S.section;   // guide + search use live TV data
const isSearch = () => S.section === 'search';
async function setSection(sec) {
  S.section = sec; S.catId = null; S.shown = 200;
  document.querySelectorAll('.rail-btn[data-sec]').forEach(b => b.classList.toggle('on', b.dataset.sec === sec));
  $('#catSearch').value = ''; $('#itemSearch').value = '';
  $('#itemSearch').placeholder = sec === 'search' ? 'Search teams, sports, channels, programmes…' : 'Search this category';
  $('#main').classList.toggle('guide-mode', sec === 'guide');
  $('#main').classList.toggle('search-mode', sec === 'search');
  S.allProgs = false;
  if (sec !== 'guide') stopGuideClock();
  if (sec === 'fav' || sec === 'recent') {
    $('#catList').innerHTML = ['live', 'movie', 'series'].map(k => `<li data-id="${k}"><span class="n">${{ live: 'TV channels', movie: 'Movies', series: 'Series' }[k]}</span></li>`).join('');
    S.catId = null; renderItems(); return;
  }
  $('#catList').innerHTML = '<li class="loading">Loading…</li>';
  $('#itemList').innerHTML = '';
  try { await loadSection(dsec()); } catch (e) { $('#catList').innerHTML = `<li class="err">${esc(e.message)}</li>`; return; }
  if (sec === 'search') { renderItems(); setTimeout(() => $('#itemSearch').focus(), 0); return; }
  if (sec === 'guide' && !S.catId) {   // start on the category of what's playing / last watched, else the first one
    const last = S.current?.kind === 'live' ? S.current : store.get('lastLive:' + S.profile.id, null);
    S.catId = (last && S.cats.live.some(c => c.id === last.cat)) ? last.cat : (visibleCats()[0]?.id || null);
  }
  renderCats(); renderItems();
}

function visibleCats() {
  const q = $('#catSearch').value.toLowerCase();
  return S.cats[dsec()].filter(c => !(S.settings.hideAdult && adultRx.test(c.name)) && c.name.toLowerCase().includes(q));
}
function renderCats() {
  const counts = {};
  for (const i of S.items[dsec()]) counts[i.cat] = (counts[i.cat] || 0) + 1;
  const cats = visibleCats();
  $('#catList').innerHTML = `<li data-id="" class="${S.catId ? '' : 'on'}"><span class="n">All</span><span class="c">${S.items[dsec()].length}</span></li>` +
    cats.map(c => `<li data-id="${esc(c.id)}" class="${S.catId === c.id ? 'on' : ''}"><span class="n">${esc(c.name)}</span><span class="c">${counts[c.id] || 0}</span></li>`).join('');
}

function renderItems() {
  const q = $('#itemSearch').value.toLowerCase();
  let list;
  if (S.section === 'fav' || S.section === 'recent') {
    list = store.get(S.section === 'fav' ? favKey() : recKey(), []);
    if (S.catId) list = list.filter(i => i.kind === S.catId);
  } else {
    const hidden = S.settings.hideAdult ? new Set(S.cats[dsec()].filter(c => adultRx.test(c.name)).map(c => c.id)) : null;
    list = S.items[dsec()].filter(i => (!S.catId || i.cat === S.catId) && !(hidden && hidden.has(i.cat)));
    list = list.map(i => ({ ...i, kind: dsec() }));
  }
  if (isSearch() && !q) list = [];
  if (q) { const sq = smartQuery(q); list = sq.empty ? list.filter(i => (i.name || '').toLowerCase().includes(q)) : list.filter(i => sq.test(nrm(i.name))); }
  // live TV / guide: also look through programme titles across every channel
  const pq = (isSearch() || S.section === 'guide') && S.profile.type === 'xtream' && q.length >= 3 ? q : '';
  const progs = pq ? progMatches(pq) : [];
  if (S.section === 'guide' && progs.length) {             // show the channels carrying matching programmes too
    const have = new Set(list.map(i => i.id));
    for (const p of progs) if (!have.has(p.ch.id)) { have.add(p.ch.id); list.push({ ...p.ch, kind: 'live' }); }
  }
  S.view = list; S.progView = isSearch() ? progs : [];
  if (S.section === 'guide') return renderGuide();
  let elsewhere = 0;
  if (q && S.catId && S.section !== 'fav' && S.section !== 'recent') {
    const hidden = S.settings.hideAdult ? new Set(S.cats[dsec()].filter(c => adultRx.test(c.name)).map(c => c.id)) : null;
    elsewhere = S.items[dsec()].filter(i => i.cat !== S.catId && !(hidden && hidden.has(i.cat)) && (i.name || '').toLowerCase().includes(q)).length;
  }
  if (isSearch() && !q) {
    $('#itemCount').textContent = '';
    $('#itemList').innerHTML = `<li class="search-hint"><b>Search everything on TV</b><span>Teams, sports, competitions, channels and programmes – e.g. <i>liverpool</i>, <i>running</i>, <i>ufc</i>, <i>england cricket</i>, <i>f1</i>. Nicknames and typos are fine.</span></li>`;
    return;
  }
  $('#itemCount').textContent = `${list.length.toLocaleString('en-GB')} ${isSearch() ? (list.length === 1 ? 'channel' : 'channels') : list.length === 1 ? 'item' : 'items'}` +
    (pq ? (xmltvState === 'loading' ? ' · searching programmes…' : ` · ${progs.length} ${progs.length === 1 ? 'programme' : 'programmes'}`) : '');
  const favSet = new Set(favs().map(f => f.kind + ':' + f.id));
  const html = list.slice(0, S.shown).map((i, idx) => {
    const img = i.icon ? `<img class="${i.kind === 'live' ? 'logo' : 'poster'}" loading="lazy" src="${esc(i.icon)}" onerror="this.style.visibility='hidden'">` : `<span class="${i.kind === 'live' ? 'logo' : 'poster'}"></span>`;
    const on = S.current && S.current.kind === i.kind && S.current.id === i.id ? 'on' : '';
    const ev = i.kind === 'live' ? eventTime(i.name) : 0;
    return `<li data-idx="${idx}" class="${on}">${i.kind === 'live' ? `<span class="num">${esc(i.num ?? '')}</span>` : ''}${img}<span class="n">${esc(i.name)}</span>${ev ? `<span class="evt" title="Event starts ${esc(whenLong(ev))}">${hhmm(ev)} <span class="cd" data-st="${ev}">${countdown(ev)}</span></span>` : ''}${favSet.has(i.kind + ':' + i.id) ? '<span class="star">★</span>' : ''}</li>`;
  }).join('');
  const other = elsewhere ? `<li class="more" data-allcats="1">${elsewhere.toLocaleString('en-GB')} more ${elsewhere === 1 ? 'match' : 'matches'} in other categories – search all</li>` : '';
  const progHtml = pq ? progListHtml(progs) : '';
  const evs = pq && isSearch() ? eventSearch(pq) : [];
  $('#itemList').innerHTML = (evs.length ? eventsHtml(evs) : '') + (evs.length && list.length ? '<li class="ev-head">Channels</li>' : '') + html + (list.length > S.shown ? `<li class="more" data-more="1">Show more (${(list.length - S.shown).toLocaleString('en-GB')} left)</li>` : '') + other +
    (list.length || other || (pq && (progs.length || xmltvState === 'loading')) ? '' : `<li class="loading">${S.section === 'fav' ? 'Star a channel, film or series to see it here.' : S.section === 'recent' ? 'Things you watch will appear here.' : 'No matches.'}</li>`) + progHtml;
}

/* ---------- Player ---------- */
// start = seconds buffered before (re)starting live; stash = mpegts read-ahead KB; hls = segments behind live edge
const BUF = {
// target = seconds behind the newest data we aim to sit at; the player quietly speeds up to stay there
  smooth:   { start: 2,   target: 1.8, stash: 128, hlsSync: 3, hlsBuf: 30 },
  balanced: { start: 1,   target: 1,   stash: 0,   hlsSync: 3, hlsBuf: 20 },
  low:      { start: 0,   target: 0.5, stash: 0,   hlsSync: 2, hlsBuf: 10 }
};
let hls = null, ts = null, wd = null, playId = 0;
const video = $('#video');
function stopPlayer() {
  stopBuiltin();
  if (S.engineNow === 'vlc') { S.engineNow = 'builtin'; window.native?.vlc?.stop(); vlcUi(false); }
}
function stopBuiltin() {
  playId++; clearInterval(wd); wd = null;
  video.onplaying = video.onwaiting = video.onerror = null;
  if (hls) { try { hls.destroy(); } catch {} hls = null; }
  if (ts) { try { ts.pause(); ts.unload(); ts.detachMediaElement(); ts.destroy(); } catch {} ts = null; }
  video.removeAttribute('src'); video.load();
}
/* ---------- Embedded VLC engine ----------
   Settings → Player: "auto" = built-in first, VLC for channels it can't play or hear; "vlc" = always VLC; "builtin" = never. */
const vlcKey = it => (it.kind || 'live') + ':' + (it.parent?.id || it.id);
const vlcSet = new Set(store.get('vlcChannels', []));
function rememberVlc(it) { vlcSet.add(vlcKey(it)); store.set('vlcChannels', [...vlcSet].slice(-500)); }
function wantsVlc(it) {
  if (TV) return true;
  if (!window.native?.vlc || S.settings.engine === 'builtin') return false;
  return S.settings.engine === 'vlc' || vlcSet.has(vlcKey(it));
}
let vlcWatch = null;
async function playVlc(url, note) {
  stopBuiltin(); soundWarn('');
  const first = S.engineNow !== 'vlc';
  S.engineNow = 'vlc'; vlcUi(true); sendVlcBounds();
  msg(note || 'Starting VLC…');
  if (first) await new Promise(r => setTimeout(r, 800));       // let the provider drop the built-in player's connection
  if (TV) window.AndroidBridge.setOptions?.(JSON.stringify({ delay: +S.settings.liveDelay || 0, keepMin: +S.settings.rewindMin || 30 }));
  const r = await window.native.vlc.play(url);
  if (TV && r.ok && S.startFull) { S.startFull = false; S.tvHinted = true; window.native.vlc.fullscreen(true); }
  if (TV && r.ok && !S.tvHinted) { S.tvHinted = true; window.AndroidBridge.toast?.('Press OK again for full screen'); }
  if (!r.ok) { S.engineNow = 'builtin'; vlcUi(false); msg('VLC couldn’t start: ' + r.error, true); return; }
  clearTimeout(vlcWatch);
  vlcWatch = setTimeout(() => { if (S.engineNow === 'vlc' && $('#vlcState').dataset.s !== 'playing' && $('#vlcState').dataset.s !== 'paused') msg('VLC couldn’t open this stream. Try another channel, or wait a moment and try again.', true); }, 20000);
}
function sendVlcBounds() {
  if (S.engineNow !== 'vlc') return;
  const r = $('#playerWrap').getBoundingClientRect();
  window.native?.vlc?.bounds({ x: r.left, y: r.top, w: r.width, h: r.height });
}
function vlcUi(on) {
  $('#vlcBar').hidden = !on; $('#playerWrap').classList.toggle('vlc-on', on);
  $('#btnLive').hidden = on || S.current?.kind !== 'live';
  if (!on) { clearTimeout(vlcWatch); if (document.body.classList.contains('vlc-full')) toggleFull(); }
}
function toggleFull() {
  if (TV) { if (S.engineNow === 'vlc') window.native.vlc.fullscreen(!S.tvFull); return; }
  if (S.engineNow === 'vlc') {                    // VLC's window isn't part of the page, so make the whole window full screen and stretch the player
    const on = !document.body.classList.contains('vlc-full');
    document.body.classList.toggle('vlc-full', on);
    if (on) document.documentElement.requestFullscreen?.().catch(() => {}); else if (document.fullscreenElement) document.exitFullscreen();
    setTimeout(sendVlcBounds, 300);
  } else $('#playerWrap').requestFullscreen?.();
}
document.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement && document.body.classList.contains('vlc-full')) { document.body.classList.remove('vlc-full'); setTimeout(sendVlcBounds, 300); } });
new ResizeObserver(sendVlcBounds).observe($('#playerWrap'));
window.addEventListener('resize', sendVlcBounds);
window.native?.vlc?.onEvent(ev => { if (ev === 'dblclick') toggleFull(); });
window.native?.vlc?.onState(s => {
  if (S.engineNow !== 'vlc') return;
  const st = $('#vlcState'); st.dataset.s = s.state;
  if (s.full !== undefined) S.tvFull = s.full;
  if (s.state === 'error') { msg(s.msg || 'Can’t play this channel.', true); clearTimeout(vlcWatch); return; }
  if (s.state === 'buffering') msg('Connecting…');
  if (s.state === 'playing') { msg(''); clearTimeout(vlcWatch); }
  if (s.state === 'exited') { S.engineNow = 'builtin'; vlcUi(false); msg('VLC closed unexpectedly – pick the channel again.', true); return; }
  st.textContent = s.state === 'playing' ? 'Playing in VLC' : s.state === 'paused' ? 'Paused' : 'Connecting…';
  $('#vlcPause').textContent = s.state === 'paused' ? '▶ Play' : '❚❚ Pause';
  if (s.volume != null) $('#vlcVol').textContent = Math.round(s.volume / 2.56) + '%';
});
let vlcLastVol = 256;
$('#vlcPause').onclick = () => window.native.vlc.cmd('command=pl_pause');
$('#vlcDown').onclick = () => window.native.vlc.cmd('command=volume&val=-26');
$('#vlcUp').onclick = () => window.native.vlc.cmd('command=volume&val=%2B26');
$('#vlcMute').onclick = async () => {
  const s = await window.native.vlc.cmd(''); if (!s) return;
  if (s.volume > 0) { vlcLastVol = s.volume; window.native.vlc.cmd('command=volume&val=0'); } else window.native.vlc.cmd('command=volume&val=' + (vlcLastVol || 256));
};
$('#vlcBuiltin').onclick = () => {                 // try the built-in player again for this channel
  if (!S.current?.url) return;
  vlcSet.delete(vlcKey(S.current)); store.set('vlcChannels', [...vlcSet]);
  const c = S.current; stopPlayer(); setTimeout(() => startItem(c, c.url, c.title), 800);
};

/* no-sound check: a muted player, or audio the built-in player can't decode (usually Dolby AC-3 / E-AC-3) */
function soundWarn(html) { const w = $('#soundWarn'); if (!w) return; w.innerHTML = html; w.hidden = !html; }
function checkSound(codec) {
  if (video.paused) return;
  const decoded = video.webkitAudioDecodedByteCount;
  window.native?.log?.(`audio: codec=${codec || '?'} decoded=${decoded} muted=${video.muted} vol=${video.volume.toFixed(2)} (${S.current?.name || ''})`);
  if (video.muted || video.volume === 0) {
    soundWarn(`<b>Sound is muted.</b> <button class="ghost" id="swUnmute">Unmute</button>`);
    $('#swUnmute').onclick = () => { video.muted = false; if (!video.volume) video.volume = 1; soundWarn(''); };
  } else if (decoded === 0 && codec !== 'none' && S.settings.engine === 'auto' && window.native?.vlc && S.current?.url) {
    rememberVlc(S.current);                       // next time this channel opens straight in VLC
    playVlc(S.current.url, 'No sound from the built-in player – switched to VLC for this channel.');
  } else if (decoded === 0 && codec !== 'none') {
    const dolby = /ac-?3|ec-?3|eac3|dolby/i.test(codec);
    soundWarn(`<b>No sound on this channel.</b> Its audio is ${dolby ? 'Dolby Digital (' + esc(codec) + ')' : esc(codec || 'in a format')} the built-in player can’t decode. <button class="ghost" id="swVlc">Open in VLC for sound</button>`);
    $('#swVlc').onclick = () => $('#btnExt').click();
  }
}
function msg(t, bad) { const m = $('#playerMsg'); m.textContent = t || ''; m.classList.toggle('bad', !!bad); m.hidden = !t; }
function ahead() {
  const b = video.buffered, t = video.currentTime;
  for (let i = 0; i < b.length; i++) if (b.start(i) <= t + 0.3 && b.end(i) > t) return b.end(i) - t;
  return 0;
}

function play(url, isLive, fallback, attempt = 0, busy = 0) {
  stopPlayer(); soundWarn(''); msg(busy ? `Provider busy – waiting for the last channel to disconnect (${busy})…` : attempt ? `Stream dropped – reconnecting (${attempt})…` : 'Connecting…');
  const id = playId, cfg = BUF[S.settings.buffer] || BUF.smooth;
  const kind = /\.m3u8(\?|$)/i.test(url) ? 'hls' : /\.(ts)(\?|$)/i.test(url) || (isLive && !/\.(mp4|mkv|avi|mov|webm)(\?|$)/i.test(url)) ? 'ts' : 'file';
  let started = 0, rebuf = isLive && cfg.start > 0, stuck = 0, lastT = -1;

  const fail = why => {
    if (id !== playId) return;
    // 469 = the provider still counts the channel you just left as connected: give it a moment, then retry the same stream
    if (!started && /\b469\b/.test(why) && busy < 4) {
      setTimeout(() => { if (id === playId) play(url, isLive, fallback, attempt, busy + 1); }, 1500 + busy * 1000);
      msg(`Provider busy – waiting for the last channel to disconnect…`); return;
    }
    // already played → the panel dropped us: reconnect to the same stream
    if (isLive && started && attempt < 6) {
      const next = Date.now() - started > 60000 ? 1 : attempt + 1;
      setTimeout(() => { if (id === playId) play(url, isLive, fallback, next); }, 800 * next);
      msg('Stream dropped – reconnecting…'); return;
    }
    if (fallback) { const f = fallback; fallback = null; play(f, isLive, null); return; }
    if (isLive && attempt < 2) { setTimeout(() => { if (id === playId) play(url, isLive, null, attempt + 1); }, 1500); return; }
    if (!/\b469\b/.test(why) && S.settings.engine === 'auto' && window.native?.vlc && S.current?.url) { rememberVlc(S.current); playVlc(S.current.url, 'The built-in player couldn’t play this – using VLC.'); return; }
    msg(/\b469\b/.test(why) ? 'Your provider refused the stream (469 – all connections on your account are in use). Stop it on other devices, or wait a minute.' : `Can’t play this here (${why}). Try “Open in VLC”.`, true);
  };
  const resume = () => { rebuf = false; video.play().catch(() => {}); };

  let audioCodec = '';
  video.onplaying = () => {
    if (id !== playId) return; msg('');
    if (!started) { started = Date.now(); setTimeout(() => { if (id === playId) checkSound(audioCodec); }, 6000); }
  };
  video.onwaiting = () => {
    if (id !== playId) return;
    msg('Buffering…');
    // live: hold until a proper cushion has built up instead of stutter-stall-stutter
    if (isLive && started && cfg.start > 0 && !rebuf) { rebuf = true; video.pause(); }
  };
  video.onerror = () => fail(video.error ? 'decoder error ' + video.error.code : 'unknown error');

  if (kind === 'hls' && window.Hls && Hls.isSupported()) {
    hls = new Hls({
      enableWorker: true, lowLatencyMode: false,
      maxBufferLength: cfg.hlsBuf, maxMaxBufferLength: cfg.hlsBuf * 2, backBufferLength: 30,
      liveSyncDurationCount: cfg.hlsSync, liveMaxLatencyDurationCount: cfg.hlsSync + 4, maxLiveSyncPlaybackRate: 1.1,
      manifestLoadingMaxRetry: 4, levelLoadingMaxRetry: 6, fragLoadingMaxRetry: 8, fragLoadingRetryDelay: 500
    });
    let mediaRecovered = 0;
    hls.on(Hls.Events.ERROR, (_e, d) => {
      if (!d.fatal || id !== playId) return;
      if (d.type === Hls.ErrorTypes.MEDIA_ERROR && mediaRecovered++ < 2) { hls.recoverMediaError(); return; }
      if (d.type === Hls.ErrorTypes.NETWORK_ERROR && started) { hls.startLoad(); return; }
      fail(d.details);
    });
    hls.on(Hls.Events.MANIFEST_PARSED, (_e, d) => { audioCodec = d.levels?.[0]?.audioCodec || ''; });
    hls.loadSource(url); hls.attachMedia(video);
  } else if (kind === 'ts' && window.mpegts && mpegts.isSupported()) {
    ts = mpegts.createPlayer({ type: 'mpegts', isLive, url }, {
      enableWorker: true, lazyLoad: false,
      enableStashBuffer: cfg.stash > 0, stashInitialSize: Math.max(cfg.stash, 64) * 1024,   // stash = hidden extra delay, keep it small
      liveBufferLatencyChasing: S.settings.buffer === 'low',   // chasing is what caused constant skipping/stalls
      liveBufferLatencyMaxLatency: 8, liveBufferLatencyMinRemain: 3,
      autoCleanupSourceBuffer: true, autoCleanupMaxBackwardDuration: 60, autoCleanupMinBackwardDuration: 30,
      fixAudioTimestampGap: true
    });
    ts.on(mpegts.Events.ERROR, (t, d, info) => fail(`${t} ${d || ''} ${info?.code || ''}`.trim()));
    ts.on(mpegts.Events.MEDIA_INFO, mi => { audioCodec = mi?.audioCodec || (mi?.hasAudio === false ? 'none' : ''); });
    if (isLive) ts.on(mpegts.Events.LOADING_COMPLETE, () => fail('stream ended'));
    ts.attachMediaElement(video); ts.load();
  } else {
    video.src = url;
  }
  video.muted = false;
  if (!rebuf) video.play().catch(() => {});

  // live watchdog: release the pre-buffer, and reconnect if the picture freezes
  if (isLive) wd = setInterval(() => {
    if (id !== playId) return;
    const a = ahead();
    if (rebuf && (a >= cfg.start || (stuck >= 8 && a > 0.5))) resume();
    const frozen = rebuf || (!video.paused && video.currentTime === lastT);
    stuck = frozen ? stuck + 1 : 0;
    lastT = video.currentTime;
    if (stuck >= 20) { stuck = 0; fail('stalled'); }
    // catch-up: every stall used to add delay permanently; now drift back towards live
    if (!rebuf && !video.paused && kind !== 'hls') {
      if (a > cfg.target + 20) { video.currentTime += a - cfg.target; }          // way behind (e.g. after a pause) → jump
      else if (a > cfg.target + 0.5) video.playbackRate = a > cfg.target + 4 ? 1.12 : 1.05;  // slightly faster, pitch kept
      else if (a < cfg.target + 0.15) video.playbackRate = 1;
    }
  }, 1000);
}

function startItem(it, url, title) {
  S.current = { ...it, url, title: title || it.name };
  $('#npTitle').textContent = S.current.title;
  ['#btnFav', '#btnExt', '#btnFull'].forEach(s => $(s).disabled = false);
  $('#btnLive').hidden = it.kind !== 'live';
  updateFavBtn();
  const isLive = it.kind === 'live';
  if (S.section === 'guide') document.querySelectorAll('#gInner .g-row').forEach(r => r.classList.toggle('on', S.view[r.dataset.i]?.id === it.id));
  if (isLive) store.set('lastLive:' + S.profile.id, { id: it.id, cat: it.cat });
  let fallback = null;
  if (isLive && S.profile.type === 'xtream') fallback = streamUrl('live', it.id, '').replace(/\.(ts|m3u8)$/, S.settings.format === 'ts' ? '.m3u8' : '.ts');
  if (wantsVlc(it)) playVlc(url); else play(url, isLive, fallback);
  pushRecent({ kind: it.kind, id: it.id, name: it.name, icon: it.icon, ext: it.ext, num: it.num, cat: it.cat });
  document.querySelectorAll('#itemList li').forEach(li => li.classList.toggle('on', S.view[li.dataset.idx]?.id === it.id));
}
function updateFavBtn() {
  if (!S.current) return;
  const target = S.current.parent || S.current;
  $('#btnFav').textContent = isFav(target) ? 'Remove from favourites' : 'Add to favourites';
}

/* ---------- Item actions ---------- */
async function openItem(it) {
  // TV: picking a channel plays it in the small window; picking the same channel again goes full screen
  if (TV && S.engineNow === 'vlc' && S.current && S.current.id === it.id && (S.current.kind || 'live') === (it.kind || 'live')) {
    window.native.vlc.fullscreen(true); return;
  }
  const d = $('#detail');
  if (it.kind === 'live') {
    startItem(it, it.direct ? it.url : streamUrl('live', it.id));
    d.innerHTML = '';
    if (S.profile.type === 'xtream') loadEpg(it);
    return;
  }
  if (it.direct) { startItem(it, it.url); d.innerHTML = ''; return; }
  if (it.kind === 'movie') {
    d.innerHTML = '<div class="loading">Loading details…</div>';
    let info = {};
    try { info = (await api('get_vod_info', `&vod_id=${it.id}`)).info || {}; } catch {}
    d.innerHTML = `<div class="vod">${info.movie_image ? `<img src="${esc(info.movie_image)}">` : ''}<div>
      <p>${esc(info.plot || info.description || 'No description.')}</p>
      <div>${[info.releasedate || info.release_date, info.duration, info.genre, info.rating ? '★ ' + info.rating : ''].filter(Boolean).map(esc).join('  |  ')}</div>
      ${info.cast ? `<div style="margin-top:6px">Cast: ${esc(info.cast)}</div>` : ''}
      <p><button class="primary" id="playMovie">Play film</button></p></div></div>`;
    $('#playMovie').onclick = () => startItem(it, streamUrl('movie', it.id, it.ext));
    S.current = { ...it, title: it.name }; $('#npTitle').textContent = it.name; $('#btnFav').disabled = false; updateFavBtn();
    return;
  }
  // series
  d.innerHTML = '<div class="loading">Loading episodes…</div>';
  $('#npTitle').textContent = it.name; S.current = { ...it, title: it.name }; $('#btnFav').disabled = false; updateFavBtn();
  let data;
  try { data = await api('get_series_info', `&series_id=${it.id}`); } catch (e) { d.innerHTML = `<p class="err">${esc(e.message)}</p>`; return; }
  const eps = data.episodes || {}, seasons = Object.keys(eps).sort((a, b) => a - b), info = data.info || {};
  if (!seasons.length) { d.innerHTML = '<p>No episodes listed for this series.</p>'; return; }
  const draw = s => {
    d.querySelectorAll('.season-tabs button').forEach(b => b.classList.toggle('on', b.dataset.s === s));
    d.querySelector('.eps').innerHTML = eps[s].map((e, i) => `<li data-i="${i}"><b>E${esc(e.episode_num)}</b><span>${esc(e.title)}</span></li>`).join('');
    d.querySelectorAll('.eps li').forEach(li => li.onclick = () => {
      const e = eps[s][li.dataset.i];
      startItem({ kind: 'series', id: it.id, name: it.name, icon: it.icon, cat: it.cat }, streamUrl('series', e.id, e.container_extension), `${it.name} – S${s} E${e.episode_num}`);
    });
  };
  d.innerHTML = `${info.plot ? `<p>${esc(info.plot)}</p>` : ''}<div class="season-tabs">${seasons.map(s => `<button class="ghost" data-s="${s}">Season ${s}</button>`).join('')}</div><ul class="eps"></ul>`;
  d.querySelectorAll('.season-tabs button').forEach(b => b.onclick = () => draw(b.dataset.s));
  draw(seasons[0]);
}

async function loadEpg(it) {
  const d = $('#detail');
  try {
    const r = await api('get_short_epg', `&stream_id=${it.id}&limit=6`);
    if (S.current?.id !== it.id) return;
    const list = (r.epg_listings || []);
    if (!list.length) { d.innerHTML = '<p>No programme guide for this channel.</p>'; return; }
    const now = Date.now() / 1000;
    const fmt = t => new Date(t * 1000).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
    d.innerHTML = '<div class="epg">' + list.map(p => {
      const st = +p.start_timestamp, en = +p.stop_timestamp, live = st <= now && now < en;
      const pct = live ? Math.round((now - st) / (en - st) * 100) : 0;
      return `<span class="t">${fmt(st)}–${fmt(en)}</span><span class="${live ? 'now' : ''}">${esc(b64(p.title))}</span>` +
        (live ? `<span></span><div class="bar"><i style="width:${pct}%"></i></div><span></span><span>${esc(b64(p.description))}</span>` : '');
    }).join('') + '</div>';
  } catch { d.innerHTML = ''; }
}


/* ---------- Programme search ----------
   Xtream panels publish the whole guide at xmltv.php. It's fetched once (in the background), trimmed to
   what's on now / coming up, and searched by title. Falls back to listings already loaded in the guide. */
let xmltv = null, xmltvFor = '', xmltvAt = 0, xmltvState = '', xmltvP = null;
const XML_ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
const unxml = s => String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
  .replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) => e[0] === '#' ? String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : +e.slice(1)) : (XML_ENT[e.toLowerCase()] ?? m)).trim();
function xmltvTime(s) {                          // "20261101200000 +0000" → unix seconds
  const m = /^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)?\s*([+-]\d{4})?/.exec(s || ''); if (!m) return 0;
  const t = Date.UTC(+m[1], m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)) / 1000;
  if (!m[7]) return t;
  const z = m[7], off = (+z.slice(1, 3) * 3600 + +z.slice(3, 5) * 60) * (z[0] === '-' ? -1 : 1);
  return t - off;
}
function loadXmltv() {
  const pid = S.profile.id;
  if (xmltv && xmltvFor === pid && Date.now() - xmltvAt < 60 * 60000) return Promise.resolve(xmltv);
  if (xmltvP && xmltvFor === pid) return xmltvP;
  xmltvFor = pid; xmltvState = 'loading';
  const p = S.profile;
  xmltvP = (async () => {
    const r = await fetch(`${base(p)}/xmltv.php?username=${encodeURIComponent(p.user)}&password=${encodeURIComponent(p.pass)}`);
    if (!r.ok) throw new Error(`guide download failed (${r.status})`);
    const txt = await r.text();
    const now = Date.now() / 1000, until = now + 8 * 86400, out = [];
    const rx = /<programme\b([^>]*)>([\s\S]*?)<\/programme>/g, attr = (a, k) => (new RegExp(`\\b${k}="([^"]*)"`).exec(a) || [])[1] || '';
    let m;
    while ((m = rx.exec(txt))) {
      const st = xmltvTime(attr(m[1], 'start')), en = xmltvTime(attr(m[1], 'stop'));
      if (!st || en <= now || st > until) continue;
      const title = unxml((/<title\b[^>]*>([\s\S]*?)<\/title>/.exec(m[2]) || [])[1]);
      const sub = unxml((/<sub-title\b[^>]*>([\s\S]*?)<\/sub-title>/.exec(m[2]) || [])[1]);
      const desc = unxml((/<desc\b[^>]*>([\s\S]*?)<\/desc>/.exec(m[2]) || [])[1]);
      const cat = [...m[2].matchAll(/<category\b[^>]*>([\s\S]*?)<\/category>/g)].map(x => unxml(x[1])).join(' ');
      out.push({ st, en, title, desc: sub && !desc.includes(sub) ? (sub + (desc ? ' – ' + desc : '')) : desc, epg: unxml(attr(m[1], 'channel')).toLowerCase(), cat,
        live: /<live\s*\/?>/.test(m[2]) || /\blive\b/i.test(title) || /^\s*live\b/i.test(desc), rerun: /<previously-shown\b/.test(m[2]) });
    }
    if (xmltvFor !== pid) return [];
    xmltv = out; xmltvAt = Date.now(); xmltvState = out.length ? 'ok' : 'empty';
    window.native?.log?.(`xmltv: ${out.length} upcoming programmes (${Math.round(txt.length / 1048576)} MB)`);
    return out;
  })().catch(e => { if (xmltvFor === pid) { xmltvState = 'failed'; xmltv = null; } window.native?.log?.('xmltv: ' + e.message); return []; })
    .finally(() => { if (xmltvFor === pid) xmltvP = null; });
  return xmltvP;
}
/* ---------- Smart matching: synonyms, topics, nicknames, typos ----------
   Every word of the search must match (in any order). A word matches its own text at a word start,
   any synonym ("soccer" ⇄ "football", "spurs" → "tottenham"), any topic expansion ("running" → marathon,
   athletics, 10k…) and, if it looks like a typo, close spellings of words that are actually in the guide. */
const SYN_GROUPS = [
  'football|soccer|futbol', 'premier league|epl|prem', 'champions league|ucl', 'europa league|uel', 'carabao cup|efl cup|league cup',
  'formula 1|formula one|f1|grand prix', 'motogp|moto gp', 'american football|nfl|gridiron', 'basketball|nba', 'ice hockey|nhl', 'baseball|mlb',
  'ufc|mma|cage fighting', 'wrestling|wwe|aew', 'darts|pdc', 'snooker|wst', 'six nations|6 nations', 'odi|one day international|one day',
  't20|twenty20|t20i', 'match of the day|motd', 'monday night football|mnf', 'sunday night football|snf',
  'manchester united|man utd|man united|man u', 'manchester city|man city', 'tottenham|spurs', 'wolverhampton|wolves', 'nottingham forest|nottm forest',
  'brighton|seagulls', 'west ham|hammers', 'newcastle|toon', 'psg|paris saint germain|paris sg', 'inter|inter milan|internazionale',
  'barcelona|barca', 'atletico|atleti', 'bayern|bayern munich', 'dortmund|bvb', 'juventus|juve',
  'south africa|proteas|springboks', 'new zealand|all blacks|black caps|blackcaps', 'australia|wallabies|aussies|socceroos',
  'west indies|windies', 'england|three lions|lionesses', 'argentina|pumas'
].map(l => l.split('|'));
// topic words widen to everything that belongs to them (one way: "running" finds marathons, not the reverse)
const TOPICS = {
  running: ['running', 'marathon', 'half marathon', 'athletics', '10k', 'parkrun', 'great north run', 'great run', 'cross country', 'ultra trail', 'road race', 'world marathon majors', 'track and field', 'diamond league'],
  athletics: ['athletics', 'marathon', 'diamond league', 'track and field', 'world athletics', 'sprint', 'relay'],
  marathon: ['marathon', 'world marathon majors'],
  football: ['football', 'soccer', 'premier league', 'championship', 'fa cup', 'efl', 'carabao cup', 'champions league', 'europa league', 'conference league', 'la liga', 'serie a', 'bundesliga', 'ligue 1', 'spfl', 'wsl', 'mls', 'futbol', 'match of the day'],
  cricket: ['cricket', 'test match', 'odi', 't20', 'ipl', 'the hundred', 'ashes', 'big bash', 'county championship', 'vitality blast'],
  rugby: ['rugby', 'six nations', 'premiership rugby', 'gallagher', 'urc', 'top 14', 'champions cup', 'super rugby', 'autumn nations', 'super league', 'challenge cup', 'rugby league'],
  ufc: ['ufc', 'mma', 'fight night', 'bellator', 'pfl'], mma: ['mma', 'ufc', 'fight night', 'bellator', 'pfl'],
  boxing: ['boxing', 'fight night', 'heavyweight', 'title fight', 'undercard'],
  fighting: ['ufc', 'mma', 'boxing', 'fight night'],
  motorsport: ['motorsport', 'f1', 'formula 1', 'formula one', 'grand prix', 'motogp', 'indycar', 'nascar', 'btcc', 'wec', 'le mans', 'formula e', 'wrc', 'rally'],
  racing: ['racing', 'horse racing', 'motorsport', 'f1', 'grand prix', 'motogp', 'nascar', 'indycar'],
  'horse racing': ['horse racing', 'racing', 'cheltenham', 'ascot', 'aintree', 'grand national', 'epsom', 'newmarket'],
  golf: ['golf', 'pga', 'dp world tour', 'ryder cup', 'the masters', 'open championship', 'liv golf', 'lpga'],
  tennis: ['tennis', 'atp', 'wta', 'wimbledon', 'us open', 'australian open', 'roland garros', 'french open', 'davis cup', 'queens'],
  cycling: ['cycling', 'tour de france', 'giro', 'vuelta', 'velodrome', 'tour of britain'],
  swimming: ['swimming', 'aquatics', 'diving'],
  nfl: ['nfl', 'american football', 'super bowl', 'redzone', 'red zone'],
  sport: ['sport', 'sports', 'live'], sports: ['sport', 'sports', 'live']
};
TOPICS.soccer = TOPICS.football; TOPICS.run = TOPICS.running; TOPICS.f1 = ['f1', 'formula 1', 'formula one', 'grand prix']; TOPICS['formula 1'] = TOPICS.f1;
const SYN_OF = new Map(); for (const g of SYN_GROUPS) for (const t of g) SYN_OF.set(t, g);
const SMART_STOP = new Set(['v', 'vs', 'versus', 'the', 'on', 'at', 'watch', 'whats', 'what', 'is', 'and', 'for', 'tonight', 'today', 'tv', 'channel']);
const nrm = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/&/g, ' and ').replace(/['’`]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();

let vocab = null, vocabFor = null;                 // distinct words in channel names + the guide, for typo correction
function buildVocab() {
  if (vocab && vocabFor === xmltv) return vocab;
  const v = new Set();
  const add = s => { for (const w of nrm(s).split(' ')) if (w.length >= 4 && !/^\d+$/.test(w)) v.add(w); };
  for (const i of S.items.live) add(i.name);
  if (xmltv) for (const p of xmltv) add(p.title);
  vocab = [...v]; vocabFor = xmltv; return vocab;
}
function editDist(a, b, max) {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i]; let best = i;
    for (let j = 1; j <= b.length; j++) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) cur[j] = Math.min(cur[j], prev[j - 2] + 1);   // swapped letters
      if (cur[j] < best) best = cur[j];
    }
    if (best > max) return max + 1;
    prev = cur;
  }
  return prev[b.length];
}
const smartCache = new Map();
// q → { terms: [{ word, alts:[...] }], test(text) → true/false, score(title, rest) }
function smartQuery(q) {
  const key = q + '|' + (xmltv ? xmltv.length : 0);
  if (smartCache.has(key)) return smartCache.get(key);
  let s = ' ' + nrm(q) + ' ';
  const terms = [];
  // phrases first ("formula 1", "american football", "horse racing", "man utd"…)
  const phrases = [...Object.keys(TOPICS), ...SYN_GROUPS.flat()].filter(p => p.includes(' ')).sort((a, b) => b.length - a.length);
  for (const p of phrases) if (s.includes(' ' + p + ' ')) { terms.push(p); s = s.replace(' ' + p + ' ', ' '); }
  terms.push(...s.trim().split(' ').filter(w => w && !SMART_STOP.has(w)));
  const words = vocab || [];
  const out = terms.map(t => {
    const alts = new Set([t]);
    (SYN_OF.get(t) || []).forEach(a => alts.add(a));
    (TOPICS[t] || []).forEach(a => alts.add(a));
    // typo: an unknown word of 5+ letters → close real words from the guide/channel names
    if (t.length >= 5 && !t.includes(' ') && !TOPICS[t] && !SYN_OF.get(t) && words.length && !words.some(w => w.startsWith(t))) {
      const max = t.length >= 8 ? 2 : 1;
      for (const w of words) if (w[0] === t[0] || w[1] === t[1]) { if (editDist(t, w, max) <= max) alts.add(w); }
    }
    const list = [...alts];
    return { word: t, alts: list, rx: new RegExp('(?:^|[^a-z0-9])(?:' + list.map(a => a.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')') };
  });
  const res = {
    terms: out, empty: !out.length,
    test: txt => out.length > 0 && out.every(t => t.rx.test(txt)),
    // 3 = every word in the title, 2 = some in the title, 1 = description only
    score: (title, rest) => { if (!out.length) return 0; let inT = 0; for (const t of out) { if (t.rx.test(title)) inT++; else if (!t.rx.test(rest)) return 0; } return inT === out.length ? 3 : inT ? 2 : 1; }
  };
  smartCache.set(key, res); if (smartCache.size > 200) smartCache.clear();
  return res;
}

// programmes (on now or later) that match the search, each paired with a channel you can play
function progMatches(q) {
  if (!(xmltv && xmltvFor === S.profile.id) && !(xmltvState === 'failed' && xmltvFor === S.profile.id)) {
    const want = q;
    loadXmltv().then(() => { if ($('#itemSearch').value.toLowerCase() === want) renderItems(); });
  }
  const now = Date.now() / 1000;
  const hidden = S.settings.hideAdult ? new Set(S.cats.live.filter(c => adultRx.test(c.name)).map(c => c.id)) : null;
  const ok = i => !(hidden && hidden.has(i.cat));
  const hits = [], seen = new Set();
  const add = (p, ch, score) => {
    const k = ch.id + ':' + p.st; if (seen.has(k)) return; seen.add(k);
    hits.push({ ...p, ch, score });
  };
  buildVocab();
  const sq = smartQuery(q); if (sq.empty) return [];
  const score = p => { if (p._t === undefined) { p._t = nrm(p.title); p._r = nrm((p.cat || '') + ' ' + p.desc); }
    const s = sq.score(p._t, p._r); return s ? s + (isLiveProg(p) ? 0.5 : 0) : 0; };
  if (xmltv && xmltvFor === S.profile.id) {
    const byEpg = new Map();
    for (const i of S.items.live) if (i.epgId && ok(i)) { const k = String(i.epgId).toLowerCase(); if (!byEpg.has(k)) byEpg.set(k, []); byEpg.get(k).push(i); }
    for (const p of xmltv) {
      if (p.en <= now) continue;
      const s = score(p); if (!s) continue;
      const chs = byEpg.get(p.epg); if (!chs) continue;
      const k = p.epg + ':' + p.st; if (seen.has(k)) continue; seen.add(k);   // one row per programme, even if several streams carry it
      hits.push({ ...p, ch: chs[0], alts: chs.length - 1, score: s });
    }
  } else {                                        // fallback: whatever the guide has already fetched
    const byId = new Map(S.items.live.map(i => [i.id, i]));
    for (const [id, c] of epgCache) { const ch = byId.get(id); if (!ch || !ok(ch)) continue; for (const p of c.list) if (p.en > now) { const s = score(p); if (s) add(p, ch, s); } }
  }
  // best matches first (whole search in the title, live coverage); then on now, then by start time
  return hits.sort((a, b) => (b.score - a.score) || ((a.st > now) - (b.st > now)) || (a.st - b.st)).slice(0, 200);
}
function progListHtml(progs) {
  const now = Date.now() / 1000;
  const day = t => { const d = new Date(t * 1000), td = new Date(); const diff = Math.round((new Date(d.toDateString()) - new Date(td.toDateString())) / 86400000);
    return diff === 0 ? 'Today' : diff === 1 ? 'Tomorrow' : d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }); };
  let h = `<li class="sec-head">On TV</li>`;
  if (!progs.length) {
    return h + `<li class="loading">${xmltvState === 'loading' ? 'Searching the programme guide…' : xmltvState === 'failed' ? 'Couldn’t download the programme guide from your provider, so only channel names were searched.' : 'No programmes on now or coming up match.'}</li>`;
  }
  const cut = S.allProgs ? progs.length : 8;
  return h + progs.slice(0, cut).map((p, k) => {
    const live = p.st <= now && now < p.en;
    return `<li class="prog${live ? ' live' : ''}" data-prog="${k}" title="${esc(p.desc || p.title)}">
      <span class="pt">${live ? '<b>On now</b>' : `${day(p.st)}<br><b class="st">${hhmm(p.st)}</b>`}<br>${live ? `<span class="cd" data-left="${p.en}">${leftText(p.en)}</span>` : `<span class="cd" data-st="${p.st}" data-en="${p.en}">${countdown(p.st, p.en)}</span>`}</span>
      <span class="pb"><span class="pn">${p.live !== undefined ? (isLiveProg(p) ? '<em class="tag live">LIVE</em>' : NOT_LIVE_RX.test(p.title + ' ' + p.desc.slice(0, 60)) || p.rerun ? '<em class="tag">REPEAT</em>' : '') : ''}${esc(p.title)}</span><span class="pc">${esc(p.ch.name)}${p.alts ? ` <i>+${p.alts}</i>` : ''} · ${hhmm(p.st)}–${hhmm(p.en)}</span></span></li>`;
  }).join('') + (progs.length > cut ? `<li class="more" data-allprogs="1">Show all ${progs.length} programmes</li>` : '');
}

/* ---------- Start times: countdowns, event channels, helper box ---------- */
function countdown(st, en) {
  const now = Date.now() / 1000;
  if (en && now >= en) return 'finished';
  if (now >= st) return en ? 'on now' : 'started';
  const m = Math.round((st - now) / 60);
  if (m < 1) return 'starting';
  if (m < 60) return `in ${m} min`;
  const h = Math.floor(m / 60);
  return h < 24 ? `in ${h}h ${String(m % 60).padStart(2, '0')}m` : `in ${Math.round(h / 24)} ${Math.round(h / 24) === 1 ? 'day' : 'days'}`;
}
function dayName(t) {
  const d = new Date(t * 1000), diff = Math.round((new Date(d.toDateString()) - new Date(new Date().toDateString())) / 86400000);
  return diff === 0 ? 'Today' : diff === 1 ? 'Tomorrow' : diff === -1 ? 'Yesterday' : d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
}
const whenLong = t => `${dayName(t)} ${hhmm(t)}`;
// keep every countdown on screen ticking
const leftText = en => { const c = countdown(en); return c.startsWith('in ') ? c.slice(3) + ' left' : 'finished'; };
setInterval(() => {
  document.querySelectorAll('.cd[data-st]').forEach(e => { e.textContent = countdown(+e.dataset.st, +e.dataset.en || 0); });
  document.querySelectorAll('.cd[data-left]').forEach(e => { e.textContent = leftText(+e.dataset.left); });
}, 20000);

// event channels often carry the kick-off in their name: "EPL 03: Arsenal v Burnley @ 20:00 UK", "UFC 310 (8pm ET) 12/07"
const TZ = { uk: 'Europe/London', bst: 'Europe/London', gmt: 'UTC', utc: 'UTC', et: 'America/New_York', est: 'America/New_York', edt: 'America/New_York',
  ct: 'America/Chicago', cst: 'America/Chicago', pt: 'America/Los_Angeles', pst: 'America/Los_Angeles', pdt: 'America/Los_Angeles', cet: 'Europe/Berlin', cest: 'Europe/Berlin' };
function zoneTime(y, mo, d, h, mi, tz) {        // wall-clock time in a zone → unix seconds
  const guess = Date.UTC(y, mo, d, h, mi) / 1000;
  if (!tz) return new Date(y, mo, d, h, mi).getTime() / 1000;   // no zone given → your PC's time
  const off = t => { const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric' }).formatToParts(new Date(t * 1000)).map(x => [x.type, x.value]));
    return Date.UTC(+p.year, p.month - 1, +p.day, +p.hour, +p.minute) / 1000 - t; };
  let t = guess - off(guess); t = guess - off(t); return t;
}
const evCache = new Map();
const MONTHS = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11 };
// pull the date/time out of an event channel name: "Liverpool v Arsenal @ Nov 1 10:30 AM :Peacock Event 02"
function eventParts(name) {
  if (!name) return null;
  const hit = evCache.get(name); if (hit) return hit.p;
  let p = null;
  const mon = /\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?\b(?:,?\s*(\d{4}))?/i.exec(name);
  const num = mon ? null : /\b(\d{1,2})[\/-](\d{1,2})(?:[\/-](\d{2,4}))?\b/.exec(name);
  const rest = name.replace(mon ? mon[0] : num ? num[0] : '\u0000', ' ');
  // needs minutes or am/pm, so "Sky Sports 1" isn't read as 1 o'clock
  const m = /(?:^|[^\d:])(2[0-3]|[01]?\d)(?:[:.h]([0-5]\d)\s*(am|pm)?|\s*(am|pm))(?![\d])\s*(uk|bst|gmt|utc|et|est|edt|ct|cst|pt|pst|pdt|cet|cest)?\b/i.exec(rest);
  if (m) {
    let h = +m[1]; const mi = +(m[2] || 0), ap = (m[3] || m[4] || '').toLowerCase();
    if (ap === 'pm' && h < 12) h += 12; if (ap === 'am' && h === 12) h = 0;
    const tz = TZ[(m[5] || '').toLowerCase()] || '';
    const now = new Date(); let y = now.getFullYear(), mo = now.getMonth(), d = now.getDate(), dated = false;
    if (mon) { mo = MONTHS[mon[1].toLowerCase()]; d = +mon[2]; if (mon[3]) y = +mon[3]; else if (mo - now.getMonth() > 6) y--; else if (now.getMonth() - mo > 6) y++; dated = true; }
    else if (num) {                               // day/month, or month/day for US-style names
      let a1 = +num[1], b1 = +num[2]; if ((/^America/.test(tz) || ap) && a1 <= 12) [a1, b1] = [b1, a1];
      if (b1 >= 1 && b1 <= 12 && a1 >= 1 && a1 <= 31) { d = a1; mo = b1 - 1; dated = true; if (num[3]) y = +num[3] < 100 ? 2000 + +num[3] : +num[3]; }
    }
    p = { y, mo, d, h, mi, tz, ampm: !!ap, dated };
  }
  evCache.set(name, { p });
  return p;
}
// start time of an event channel. Without a zone in the name, AM/PM names are US-style feeds (Eastern time);
// pass `near` (a known kick-off) to pick whichever zone makes the time land just before it.
function eventTime(name, near) {
  const p = eventParts(name); if (!p) return 0;
  const at = tz => { let t = zoneTime(p.y, p.mo, p.d, p.h, p.mi, tz); if (!p.dated && Date.now() / 1000 - t > 12 * 3600) t += 86400; return t; };
  if (!p.tz && near) {
    for (const tz of ['Europe/London', 'America/New_York', 'Europe/Berlin', 'America/Chicago', 'America/Los_Angeles']) {
      const t = at(tz); if (near - t >= -15 * 60 && near - t <= 4 * 3600) return t;
    }
  }
  const t = at(p.tz || (p.ampm ? 'America/New_York' : ''));
  if (!near && Date.now() / 1000 - t > 5 * 3600) return 0;       // long finished – don't badge it
  return t;
}

/* ---------- Events: what's on, when it starts, where to watch (football, rugby, cricket, UFC) ----------
   Official start times come from ESPN's public schedules; anything ESPN doesn't cover (cricket, smaller
   events) is built from your provider's own data: event-channel names and the programme guide. */
const SCHED = [
  ...['eng.1', 'eng.2', 'eng.fa', 'eng.league_cup', 'sco.1', 'uefa.champions', 'uefa.europa', 'uefa.europa.conf', 'esp.1', 'ger.1',
      'ita.1', 'fra.1', 'uefa.nations', 'fifa.worldq.uefa', 'fifa.world', 'eng.w.1', 'fifa.friendly'].map(l => ({ path: 'soccer/' + l, sport: 'Football' })),
  ...['267979', '180659', '270557', '271937', '272073', '164205', '289234', '270559', '242041'].map(l => ({ path: 'rugby/' + l, sport: 'Rugby' })),
  { path: 'mma/ufc', sport: 'UFC' }
];
const COMP_NAMES = ['Premier League', 'Championship', 'FA Cup', 'Carabao Cup', 'EFL Cup', 'League One', 'League Two', 'Champions League', 'Europa League',
  'Conference League', 'La Liga', 'Serie A', 'Bundesliga', 'Ligue 1', 'Scottish Premiership', 'SPFL', 'Nations League', 'World Cup', 'WSL', "Women's Super League", 'MLS',
  'Six Nations', 'Premiership Rugby', 'Gallagher Premiership', 'URC', 'United Rugby Championship', 'Top 14', 'Champions Cup', 'Challenge Cup', 'Autumn Nations Series',
  'Rugby Championship', 'Super Rugby', 'Super League', 'Rugby World Cup',
  'Test Match', 'Test', 'ODI', 'One-Day International', 'T20 World Cup', 'T20I', 'T20', 'IPL', 'The Hundred', 'Big Bash', 'County Championship', 'Ashes', 'Vitality Blast',
  'UFC Fight Night', 'UFC'];
const SPORT_RX = [
  ['UFC', /\bufc\b|\bmma\b/],
  ['Athletics', /marathon|athletics|diamond league|track and field|\bparkrun\b|great north run|cross country/],
  ['Cricket', /cricket|\btest match|\bodi\b|\bt20|\bipl\b|the hundred|\bashes\b|big bash|county championship|vitality blast|\bfirst ball\b/],
  ['Rugby', /rugby|six nations|gallagher|\burc\b|top 14|champions cup|super rugby|autumn nations|\bsuper league\b|challenge cup/],
  ['Boxing', /boxing|fight night|heavyweight/],
  ['Motorsport', /\bf1\b|formula (1|one|e)|grand prix|motogp|indycar|nascar|\bbtcc\b|le mans|\bwrc\b/],
  ['Golf', /\bgolf\b|\bpga\b|ryder cup|dp world tour|the masters|open championship/],
  ['Tennis', /tennis|\batp\b|\bwta\b|wimbledon|roland garros|davis cup/],
  ['Darts', /\bdarts\b|\bpdc\b/], ['Snooker', /snooker/], ['Cycling', /cycling|tour de france|\bgiro\b|vuelta/],
  ['NFL', /\bnfl\b|american football|super bowl/], ['Horse racing', /horse racing|racecourse|cheltenham|ascot|aintree/],
  ['Football', /football|soccer|premier league|\bepl\b|championship|fa cup|carabao|\befl\b|champions league|europa|la liga|serie a|bundesliga|ligue 1|spfl|\bwsl\b|\bmls\b|futbol/]
];
const START_WORD = { Football: 'Kick-off', Rugby: 'Kick-off', Cricket: 'Play starts', UFC: 'Starts' };
let sched = null, schedAt = 0, schedP = null, schedState = '';
const ymd = d => d.toISOString().slice(0, 10).replace(/-/g, '');
function loadSched() {
  if (sched && Date.now() - schedAt < 20 * 60000) return Promise.resolve(sched);
  if (schedP) return schedP;
  schedState = 'loading';
  const from = ymd(new Date(Date.now() - 86400000)), to = ymd(new Date(Date.now() + 8 * 86400000));
  schedP = Promise.all(SCHED.map(s => fetch(`https://site.api.espn.com/apis/site/v2/sports/${s.path}/scoreboard?dates=${from}-${to}&limit=300`)
    .then(r => r.ok ? r.json() : null).catch(() => null).then(d => {
      if (!d) return [];
      const comp = (d.leagues?.[0]?.name || '').replace(/^(English|Spanish|German|Italian|French) /, '');
      return (d.events || []).map(e => {
        const c = e.competitions?.[0] || {}, cs = c.competitors || [];
        const base = { src: 'espn', sport: s.sport, comp: s.sport === 'UFC' ? 'UFC' : comp, start: Date.parse(e.date) / 1000,
          state: e.status?.type?.state || 'pre', detail: e.status?.type?.shortDetail || '' };
        if (s.sport === 'UFC') {                    // one "event" = a fight card; headline from the name ("UFC 310: Pantoja vs. Asakura")
          const [code, main = ''] = String(e.name || '').split(/:\s*/);
          const [fa = '', fb = ''] = main.split(/\s+vs?\.?\s+/i);
          const names = (e.competitions || []).flatMap(x => (x.competitors || []).map(y => y.athlete?.displayName || '')).filter(Boolean);
          if (!fa || !fb) return null;
          return { ...base, comp: code.trim() || 'UFC', title: main || e.name, code: norm(code), a: { name: fa, keys: [norm(fa).split(' ').pop()] }, b: { name: fb, keys: [norm(fb).split(' ').pop()] },
            words: norm([e.name, ...names].join(' ')), last: Math.max(base.start, ...(e.competitions || []).map(x => Date.parse(x.date) / 1000 || 0)) };
        }
        const home = cs.find(x => x.homeAway === 'home') || cs[0], away = cs.find(x => x.homeAway === 'away') || cs[1];
        if (!home || !away) return null;
        const team = x => { const t = { name: x.team?.shortDisplayName || x.team?.displayName || '', full: x.team?.displayName || '', score: x.score }; t.keys = teamKeys(t); return t; };
        const a = team(home), b = team(away);
        return { ...base, title: `${a.name} v ${b.name}`, a, b, words: [norm(comp), norm(s.sport), ...a.keys, ...b.keys].join(' | ') };
      }).filter(Boolean);
    })))
    .then(all => { sched = all.flat(); schedAt = Date.now(); schedState = sched.length ? 'ok' : 'failed';
      window.native?.log?.(`schedules: ${sched.length} events from ESPN`); return sched; })
    .finally(() => { schedP = null; });
  return schedP;
}
const norm = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9& ]+/g, ' ').replace(/\s+/g, ' ').trim();
const ALIAS = { 'manchester united': ['man utd', 'man united', 'man u'], 'manchester city': ['man city'], 'tottenham hotspur': ['spurs', 'tottenham'],
  'wolverhampton wanderers': ['wolves'], 'nottingham forest': ['nottm forest', 'nott m forest', 'forest'], 'brighton & hove albion': ['brighton'],
  'west ham united': ['west ham'], 'newcastle united': ['newcastle'], 'leeds united': ['leeds'], 'afc bournemouth': ['bournemouth'],
  'paris saint germain': ['psg', 'paris sg'], 'internazionale': ['inter milan', 'inter'], 'bayern munich': ['bayern'], 'borussia dortmund': ['dortmund', 'bvb'],
  'atletico madrid': ['atletico', 'atleti'], 'sheffield united': ['sheff utd', 'sheffield utd'], 'queens park rangers': ['qpr'], 'west bromwich albion': ['west brom'],
  'south africa': ['proteas', 'springboks', 'sa'], 'new zealand': ['all blacks', 'black caps', 'blackcaps', 'nz'], 'australia': ['wallabies', 'aus'],
  'west indies': ['windies', 'wi'], 'england': ['eng'], 'india': ['ind'], 'pakistan': ['pak'], 'sri lanka': ['sl'], 'argentina': ['pumas'] };
const ALIAS_BACK = Object.fromEntries(Object.entries(ALIAS).flatMap(([k, v]) => v.map(a => [a, k])));
function teamKeys(t) {
  const k = new Set([norm(t.name), norm(t.full)]);
  const f = ALIAS_BACK[norm(t.full)] || norm(t.full); k.add(f); (ALIAS[f] || []).forEach(a => a.length >= 3 && k.add(a));
  const trimmed = f.replace(/^(afc|fc) /, '').replace(/ (fc|afc|rfc|ccc)$/, '');
  k.add(trimmed);
  if (!/^(manchester|sheffield|west|bristol|real|athletic|inter|south|new|sri)\b/.test(trimmed)) k.add(trimmed.replace(/ (united|city|hotspur|wanderers|albion|rovers|athletic|town|county|rugby)$/, ''));
  return [...k].filter(x => x.length >= 3);
}
const mentions = (txt, keys) => keys.some(k => k && new RegExp(`(^|[^a-z])${k.replace(/[&]/g, '\\$&')}([^a-z]|$)`).test(txt));
const STOP = new Set(['v', 'vs', 'versus', 'fc', 'afc', 'and', 'the', 'live', 'match', 'game', 'tonight', 'today']);
const sportOf = txt => (SPORT_RX.find(([, rx]) => rx.test(txt)) || [''])[0];
const compOf = txt => { const t = ' ' + txt.toLowerCase() + ' '; return COMP_NAMES.find(c => new RegExp(`[^a-z]${c.toLowerCase().replace(/[-']/g, '.')}[^a-z]`).test(t)) || ''; };

// replays, highlights, classics etc. are never "the match"
const NOT_LIVE_RX = /\b(highlights?|replay|repeat|classic|classics|rewind|review|preview|build.?up|reaction|magazine|best of|greatest|archive|documentary|recap|delayed|encore|re.?run|from (?:earlier|yesterday))\b|\(r\)/i;
const isLiveProg = p => (p.live || /\blive\b/i.test(p.title)) && !NOT_LIVE_RX.test(p.title) && !(p.rerun && !/\blive\b/i.test(p.title));
// "Live: England v South Africa – 2nd Test" → ['England', 'South Africa']
function splitVs(s) {
  const m = /(^|.*?[:|•@\-–(\[]\s*|^live\s+)([^:|•@\-–(\[]{2,40}?)\s+(?:v|vs\.?|versus)\s+([^:|•@\-–()\[\],.]{2,40})/i.exec(String(s || ''));
  if (!m) return null;
  const clean = x => x.replace(/^(live|epl|nfl|ufc|mlb|nba|nhl|ppv|event|ko)\b[\s:]*/i, '').replace(/^\d+\s*/, '')
    .replace(/\s+(live|kick.?off|ko|at|in|on|from|day|first|\d+(st|nd|rd|th)|test|odi|t20i?|highlights|preview|replay|\d{1,2}[:.]\d{2}.*|\d{1,2}\s*(am|pm).*)$/i, '').trim();
  let a = clean(m[2]), b = clean(m[3]);
  b = b.split(/\s+(?=(?:live|kick|ko|at|day|first|test|odi|t20|in|from|\d))/i)[0].trim();
  if (a.length < 2 || b.length < 2 || /^(the|a)$/i.test(a)) return null;
  return [a, b];
}
// "(Kick-off 4.30pm)", "first ball 10.30am", "Main card from 3am" → unix time on the programme's day
function startFromText(txt, p) {
  const m = /\b(?:kick[\s-]?off|k\.?o\.?|first ball|play (?:starts|begins)|main card|prelims|starts? at)\b[^0-9]{0,14}(\d{1,2})(?:[.:](\d{2}))?\s*(am|pm)?/i.exec(txt);
  if (!m) return 0;
  let h = +m[1]; const mi = +(m[2] || 0), ap = (m[3] || '').toLowerCase();
  if (ap === 'pm' && h < 12) h += 12; if (ap === 'am' && h === 12) h = 0;
  if (!ap && h < 9) h += 12;                      // "kick-off 4.30" means the afternoon
  const d = new Date(p.st * 1000); let t = new Date(d.getFullYear(), d.getMonth(), d.getDate(), h, mi).getTime() / 1000;
  if (t < p.st - 3600) t += 86400;
  return t >= p.st - 3600 && t <= p.en + 3600 ? t : 0;
}

function eventSearch(q) {
  const want = q;
  const again = () => { if ($('#itemSearch').value.toLowerCase() === want) renderItems(); };
  if (!sched && schedState !== 'failed') loadSched().then(again);
  buildVocab();
  const sq = smartQuery(q); if (sq.empty) return [];
  const hit = txt => sq.test(txt);
  const now = Date.now() / 1000, hidden = S.settings.hideAdult ? new Set(S.cats.live.filter(c => adultRx.test(c.name)).map(c => c.id)) : null;
  const okCh = ch => !(hidden && hidden.has(ch.cat));
  const haveGuide = xmltv && xmltvFor === S.profile.id;
  const byEpg = new Map();
  if (haveGuide) for (const i of S.items.live) if (i.epgId && okCh(i)) { const k = String(i.epgId).toLowerCase(); if (!byEpg.has(k)) byEpg.set(k, []); byEpg.get(k).push(i); }

  // 1. official schedule
  const events = (sched || []).filter(e => e.state !== 'post' && (e.last || e.start) > now - 4 * 3600 && hit(e.words))
    .map(e => ({ ...e, where: [] }));
  // where to watch an official event: every channel named after it, and every live programme covering it
  const coversText = (e, txt) => (e.code && /\bufc\b/.test(txt) && txt.includes(e.code)) || (mentions(txt, e.a.keys) && mentions(txt, e.b.keys));
  events.sort((x, y) => x.start - y.start);
  for (const e of events.slice(0, 10)) {
    for (const ch of S.items.live) {
      if (!okCh(ch)) continue;
      const n = norm(ch.name); if (!coversText(e, n)) continue;
      const p = eventParts(ch.name);
      if (p?.dated && Math.abs(zoneTime(p.y, p.mo, p.d, 12, 0, '') - e.start) > 2 * 86400) continue;   // another meeting of the same sides
      e.where.push({ ch, from: eventTime(ch.name, e.start) || 0 });
    }
    if (!haveGuide) continue;
    const from = e.start - (e.sport === 'UFC' ? 3600 : -15 * 60), to = (e.last || e.start) + (e.sport === 'UFC' ? 3600 : 20 * 60);
    for (const p of xmltv) {
      if (p.st > from || p.en < to) continue;                 // must be on air across the start
      if (NOT_LIVE_RX.test(p.title) || (p.rerun && !p.live)) continue;
      const chs = byEpg.get(p.epg); if (!chs) continue;
      if (!coversText(e, norm(p.title + ' ' + p.desc))) continue;
      e.where.push({ ch: chs[0], alts: chs.length - 1, from: p.st, title: p.title });
    }
  }
  // 2. provider data: event channels + guide programmes that match the search and name two sides
  const cands = [];
  for (const ch of S.items.live) {
    if (!okCh(ch)) continue;
    const n = norm(ch.name); if (!hit(n)) continue;
    const vs = splitVs(ch.name); if (!vs) continue;
    cands.push({ kind: 'event', ch, vs, text: n + ' ' + norm(ch.name), raw: ch.name });
  }
  if (haveGuide) {
    let c = 0;
    for (const p of xmltv) {
      if (p.en <= now) continue;
      if (p._t === undefined) { p._t = nrm(p.title); p._r = nrm((p.cat || '') + ' ' + p.desc); }
      if (!hit(p._t + ' ' + p._r)) continue;
      const txt = norm(p.title + ' ' + p.desc);
      const chs = byEpg.get(p.epg); if (!chs || NOT_LIVE_RX.test(p.title) || (p.rerun && !p.live)) continue;
      let vs = splitVs(p.title); if (!vs) for (const s of p.desc.split(/(?<=[.!?])\s/).slice(0, 3)) if ((vs = splitVs(s))) break;
      cands.push({ kind: 'guide', live: isLiveProg(p), p, ch: chs[0], alts: chs.length - 1, vs, text: txt + ' ' + norm(chs[0].name), raw: p.title + ' ' + p.desc });
      if (++c > 600) break;
    }
  }
  // attach each candidate to an official event, or group it into a provider-built one
  const covers = (e, c) => {
    if (e.code && /\bufc\b/.test(c.text) && (c.text.includes(e.code) || (mentions(c.text, e.a.keys) && mentions(c.text, e.b.keys)))) return true;
    return mentions(c.text, e.a.keys) && mentions(c.text, e.b.keys);
  };
  const own = [];
  for (const c of cands) {
    const sport = sportOf(c.text + ' ' + norm(c.ch.name));
    let tv = c.kind === 'event' ? eventTime(c.ch.name) : c.p.st, until = c.kind === 'guide' ? c.p.en : 0;
    let e = events.find(e => covers(e, c) && (!tv || Math.abs(tv - e.start) < 8 * 3600) && (!until || until > e.start));
    if (e) {
      if (c.kind === 'event') tv = eventTime(c.ch.name, e.start) || tv;
      if (c.kind === 'guide' && !(c.p.st <= e.start + 15 * 60 && c.p.en >= e.start + 20 * 60) && e.sport !== 'UFC') { if (c.p.en < e.start || c.p.st > e.start + 3 * 3600) continue; }
      e.where.push({ ch: c.ch, alts: c.alts, from: tv, title: c.kind === 'guide' ? c.p.title : '' });
      continue;
    }
    if (!c.vs && c.kind === 'guide' && c.live && sport) {          // live sport without two sides: a marathon, a race, a golf round…
      const t = c.p.title.replace(/^\s*live\s*[:\-–]?\s*/i, '').trim() || c.p.title, k = nrm(t);
      let s1 = own.find(o => o.single && o.key === k && Math.abs(o.tvFirst - c.p.st) < 12 * 3600);
      if (!s1) { s1 = { src: 'tv', single: t, key: k, sport, comp: compOf(c.raw + ' ' + c.ch.name), a: { name: t, keys: [] }, b: { name: '', keys: [] }, title: t, start: 0, tvFirst: c.p.st, where: [] }; own.push(s1); }
      if (c.p.st < s1.tvFirst) s1.tvFirst = c.p.st;
      const st1 = startFromText(c.raw, c.p); if (st1 && !s1.start) s1.start = st1;
      s1.where.push({ ch: c.ch, alts: c.alts, from: c.p.st, to: c.p.en, title: c.p.title });
      continue;
    }
    if (!c.vs || !sport || (c.kind === 'guide' && !c.live)) continue;   // a card of its own needs live coverage, not a repeat
    const keysA = teamKeys({ name: c.vs[0], full: c.vs[0] }), keysB = teamKeys({ name: c.vs[1], full: c.vs[1] });
    const start = c.kind === 'guide' ? startFromText(c.raw, c.p) : 0;
    e = own.find(o => o.sport === sport && ((mentions(c.text, o.a.keys) && mentions(c.text, o.b.keys)) || (mentions(norm(o.a.name + ' ' + o.b.name), keysA) && mentions(norm(o.a.name + ' ' + o.b.name), keysB)))
      && Math.abs((tv || 0) - (o.tvFirst || tv || 0)) < (sport === 'Cricket' ? 6 * 86400 : 12 * 3600));
    if (!e) { e = { src: 'tv', sport, comp: '', a: { name: c.vs[0], keys: keysA }, b: { name: c.vs[1], keys: keysB }, title: `${c.vs[0]} v ${c.vs[1]}`, start: 0, tvFirst: tv, where: [] }; own.push(e); }
    e.comp = e.comp || compOf(c.raw + ' ' + c.ch.name);
    if (start && (!e.start || (start < e.start && start > now - 8 * 3600))) e.start = start;
    if (tv && (!e.tvFirst || tv < e.tvFirst)) e.tvFirst = tv;
    e.where.push({ ch: c.ch, alts: c.alts, from: tv, to: until, title: c.kind === 'guide' ? c.p.title : '' });
  }
  for (const o of own) { o.state = o.start && o.start <= now ? 'in' : (!o.start && o.tvFirst && o.tvFirst <= now ? 'tvon' : 'pre'); }
  const all = [...events, ...own.filter(o => o.where.length)];
  for (const e of all) {                          // one row per channel, earliest TV start first
    const seen = new Set();
    e.where = e.where.sort((x, y) => (x.from || 9e12) - (y.from || 9e12)).filter(w => { const k = w.ch.epgId || w.ch.id; if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, 10);
    e.when = e.start || e.tvFirst || 0;
  }
  // on now first, then soonest; events you can actually watch ahead of ones you can't
  return all.filter(e => e.when > now - 6 * 3600 && e.when < now + 8 * 86400)
    .sort((x, y) => (!x.where.length - !y.where.length) || ((x.state === 'in' || x.state === 'tvon' ? 0 : 1) - (y.state === 'in' || y.state === 'tvon' ? 0 : 1)) || x.when - y.when)
    .slice(0, 6);
}

function eventsHtml(evs) {
  S.fixView = evs;
  const now = Date.now() / 1000;
  return `<li class="ev-head">Matches &amp; events</li>` + evs.map((e, fi) => {
    const live = e.state === 'in', word = START_WORD[e.sport] || 'Starts';
    const badge = live ? `<span class="ev-badge live">LIVE${e.src === 'espn' && e.a.score != null && e.sport !== 'UFC' ? ` ${esc(e.a.score)}–${esc(e.b.score)}` : ''}</span>`
      : e.start ? `<span class="ev-badge cd" data-st="${e.start}">${countdown(e.start)}</span>` : '';
    const big = e.start
      ? `<div class="ev-ko"><span class="ev-kow">${word}</span><span class="ev-kot">${hhmm(e.start)}</span><span class="ev-kod">${esc(dayName(e.start))}${live && e.detail ? ' · ' + esc(e.detail) : ''}</span></div>`
      : `<div class="ev-ko"><span class="ev-kow">On TV from</span><span class="ev-kot">${e.tvFirst ? hhmm(e.tvFirst) : '–'}</span><span class="ev-kod">${e.tvFirst ? esc(dayName(e.tvFirst)) : ''} · ${e.sport === 'Football' || e.sport === 'Rugby' ? 'kick-off' : 'start'} time not listed</span></div>`;
    const rows = e.where.length ? e.where.map((w, wi) => `<div class="ev-row" data-fx="${fi}:${wi}" title="Watch ${esc(w.ch.name)}">
        <span class="ev-play">▶</span>
        <span class="ev-ch">${w.ch.icon ? `<img src="${esc(w.ch.icon)}" onerror="this.style.visibility='hidden'">` : '<i></i>'}<span class="ev-cn">${esc(w.ch.name)}${w.alts ? ` <em>+${w.alts} more</em>` : ''}${w.title ? `<small>${esc(w.title)}</small>` : ''}</span></span>
        <span class="ev-from">${w.from ? `<small>TV from</small><b>${hhmm(w.from)}</b>` : '<small>time not<br>listed</small>'}</span></div>`).join('')
      : `<div class="ev-none">Not on any of your channels yet – event channels usually appear on the day.</div>`;
    return `<li class="ev-card${live ? ' is-live' : ''}">
      <div class="ev-top"><span class="ev-sport">${esc(e.sport)}${e.comp && e.comp !== e.sport ? ' · ' + esc(e.comp) : ''}</span>${badge}</div>
      <div class="ev-title">${e.single ? esc(e.single) : `${esc(e.a.name)} <span>v</span> ${esc(e.b.name)}`}</div>${big}
      <div class="ev-where">${rows}</div></li>`;
  }).join('');
}

// a programme picked from search: on now → watch it; later → show when it starts
function openProg(p) {
  const now = Date.now() / 1000, ch = { ...p.ch, kind: 'live' };
  if (p.st <= now && now < p.en) { openItem(ch); return; }
  $('#detail').innerHTML = `<div class="progbox">
    <div class="pb-when"><b>${hhmm(p.st)}</b><span>${dayName(p.st)}</span></div>
    <div class="pb-main"><h3>${esc(p.title)}</h3>
      <div class="dim">${esc(p.ch.name)} · ${hhmm(p.st)}–${hhmm(p.en)} · <span class="cd" data-st="${p.st}" data-en="${p.en}">${countdown(p.st, p.en)}</span></div>
      ${p.desc ? `<p>${esc(p.desc)}</p>` : ''}
      <button class="ghost" id="pbWatch">Watch ${esc(p.ch.name)} now</button></div></div>`;
  $('#pbWatch').onclick = () => openItem(ch);
}

/* ---------- TV guide ---------- */
const PPM = 5, G_HOURS = 24;                     // px per minute, hours shown
let CH = store.get('guideCh', 260);              // channel-name column width (drag its edge to change)
document.documentElement.style.setProperty('--gch', CH + 'px');
const epgCache = new Map();                      // stream id -> { at, list }
let gStart = 0, gObs = null, gClock = null, gQueue = [], gActive = 0;
const hhmm = t => new Date(t * 1000).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
const gx = t => CH + (t - gStart) / 60 * PPM;
function stopGuideClock() { clearInterval(gClock); gClock = null; }

function renderGuide() {
  const box = $('#gInner'), scroller = $('#gScroll');
  if (S.profile.type !== 'xtream') { box.innerHTML = '<p class="loading">The TV guide needs an Xtream Codes login (M3U links don’t include programme data).</p>'; return; }
  const now = Date.now() / 1000;
  gStart = Math.floor(now / 1800) * 1800 - 3600;             // from an hour ago
  const W = CH + G_HOURS * 60 * PPM, rows = S.view.slice(0, S.shown);
  let head = `<div class="g-head" style="width:${W}px"><div class="g-corner">${new Date().toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })}<div class="g-chresize" title="Drag to widen channel names · double-click to reset"></div></div>`;
  for (let t = gStart; t < gStart + G_HOURS * 3600; t += 1800) head += `<div class="g-tick" style="left:${gx(t)}px">${hhmm(t)}</div>`;
  head += '</div>';
  const body = rows.map((c, i) => `<div class="g-row${S.current?.kind === 'live' && S.current.id === c.id ? ' on' : ''}" data-i="${i}" style="width:${W}px">
      <div class="g-ch" data-play="${i}" title="Watch ${esc(c.name)}">${c.icon ? `<img src="${esc(c.icon)}" loading="lazy" onerror="this.style.visibility='hidden'">` : '<span class="g-noimg"></span>'}<span class="g-num">${esc(c.num ?? '')}</span><span class="g-name">${esc(c.name)}</span></div>
      <div class="g-progs"><span class="g-empty" style="left:${CH + 8}px">Loading…</span></div></div>`).join('');
  const more = S.view.length > S.shown ? `<button class="ghost g-more" data-more="1">Show more channels (${(S.view.length - S.shown).toLocaleString('en-GB')} left)</button>` : '';
  box.style.width = W + 'px';
  box.innerHTML = head + body + `<div class="g-now" id="gNowLine"></div>` + more + (rows.length ? '' : '<p class="loading">No channels in this category.</p>');
  $('#gInfo').innerHTML = '<span class="dim">Click a programme for details · click a channel name (or anything on now) to watch</span>';
  placeNowLine();
  scroller.scrollLeft = Math.max(0, gx(now) - CH - 90 * PPM / 3);
  scroller.scrollTop = 0;
  // fetch listings only for rows that scroll into view
  gObs?.disconnect(); gQueue = [];
  gObs = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { gObs.unobserve(e.target); queueRow(e.target); } }), { root: scroller, rootMargin: '300px 0px' });
  box.querySelectorAll('.g-row').forEach(r => gObs.observe(r));
  stopGuideClock(); gClock = setInterval(() => { placeNowLine(); markLive(); }, 30000);
}
// a programme that started off to the left keeps its title in view, just right of the channel column
let gTitleRaf = 0;
// Titles only depend on the horizontal position, so scrolling up/down costs nothing; new rows are fixed as they load.
// Programme positions come from their inline style (no layout reads), which keeps fast scrolling smooth on slow boxes.
let gTitleLeft = -1;
function fixRowTitles(row, edge) {
  for (const p of row.querySelectorAll('.g-prog')) {
    const l = parseFloat(p.style.left) || 0, w = parseFloat(p.style.width) || 0;
    const pad = l < edge && l + w > edge + 40 ? Math.min(edge - l + 8, w - 40) : 0;
    if ((p._pad || 0) !== pad) { p.style.paddingLeft = pad ? pad + 'px' : ''; p._pad = pad; }
  }
}
function fixGuideTitles(force) {
  gTitleRaf = 0;
  const sc = $('#gScroll'); if (!sc) return;
  if (!force && sc.scrollLeft === gTitleLeft) return;
  gTitleLeft = sc.scrollLeft;
  const edge = sc.scrollLeft + CH;
  for (const row of document.querySelectorAll('#gInner .g-row')) if (row._progs) fixRowTitles(row, edge);
}
const queueGuideTitles = () => { if (!gTitleRaf) gTitleRaf = requestAnimationFrame(() => fixGuideTitles(false)); };
$('#gScroll').addEventListener('scroll', queueGuideTitles, { passive: true });
function placeNowLine() { const l = $('#gNowLine'); if (l) l.style.left = gx(Date.now() / 1000) + 'px'; }
function markLive() {
  const now = Date.now() / 1000;
  document.querySelectorAll('#gInner .g-prog').forEach(p => {
    p.classList.toggle('live', +p.dataset.st <= now && now < +p.dataset.en);
    p.classList.toggle('past', +p.dataset.en <= now);
  });
}
function queueRow(row) { gQueue.push(row); pumpQueue(); }
function pumpQueue() {
  while (gActive < 5 && gQueue.length) {
    const row = gQueue.shift();
    if (!row.isConnected) continue;
    const sc = $('#gScroll'), r = row.getBoundingClientRect(), s = sc.getBoundingClientRect();
    if (r.bottom < s.top - 600 || r.top > s.bottom + 600) { gObs?.observe(row); continue; }   // flew past it: fetch when it comes back
    gActive++;
    loadRow(row).finally(() => { gActive--; pumpQueue(); });
  }
}
async function fetchEpg(id) {
  const c = epgCache.get(id);
  if (c && Date.now() - c.at < 30 * 60000) return c.list;
  let list = [];
  try { list = (await api('get_simple_data_table', `&stream_id=${id}`)).epg_listings || []; } catch {}
  if (!list.length) { try { list = (await api('get_short_epg', `&stream_id=${id}&limit=50`)).epg_listings || []; } catch {} }
  list = list.map(p => ({ st: +p.start_timestamp, en: +p.stop_timestamp, title: b64(p.title), desc: b64(p.description) }))
    .filter(p => p.st && p.en > p.st).sort((a, b) => a.st - b.st)
    .filter((p, i, a) => !i || p.st !== a[i - 1].st);           // drop duplicates
  epgCache.set(id, { at: Date.now(), list });
  return list;
}
async function loadRow(row) {
  const ch = S.view[row.dataset.i]; if (!ch) return;
  const list = await fetchEpg(ch.id);
  if (!row.isConnected) return;
  const gEnd = gStart + G_HOURS * 3600, now = Date.now() / 1000;
  const progs = list.filter(p => p.en > gStart && p.st < gEnd), gq = $('#itemSearch').value.toLowerCase();
  row.querySelector('.g-progs').innerHTML = progs.length ? progs.map((p, j) => {
    const a = Math.max(p.st, gStart), b = Math.min(p.en, gEnd);
    const cls = (p.st <= now && now < p.en ? ' live' : p.en <= now ? ' past' : '') + (gq.length >= 3 && (p.title + ' ' + p.desc).toLowerCase().includes(gq) ? ' hit' : '');
    return `<div class="g-prog${cls}" data-st="${p.st}" data-en="${p.en}" data-j="${j}" style="left:${gx(a)}px;width:${Math.max(4, (b - a) / 60 * PPM - 3)}px" title="${hhmm(p.st)}–${hhmm(p.en)}  ${esc(p.title)}"><b>${esc(p.title)}</b><span>${hhmm(p.st)}–${hhmm(p.en)}</span></div>`;
  }).join('') : `<span class="g-empty" style="left:${CH + 8}px">No guide data for this channel</span>`;
  row._progs = progs;
  fixRowTitles(row, $('#gScroll').scrollLeft + CH);
}
$('#gInner').onclick = e => {
  if (e.target.closest('[data-more]')) { S.shown += 200; renderGuide(); return; }
  const row = e.target.closest('.g-row'); if (!row) return;
  const ch = S.view[row.dataset.i]; if (!ch) return;
  const pe = e.target.closest('.g-prog');
  if (pe) {
    const p = row._progs[pe.dataset.j], now = Date.now() / 1000, live = p.st <= now && now < p.en;
    $('#gInfo').innerHTML = `<b>${esc(p.title)}</b> <span class="dim">${esc(ch.name)} · ${dayName(p.st)} ${hhmm(p.st)}–${hhmm(p.en)} · <span class="cd" data-st="${p.st}" data-en="${p.en}">${countdown(p.st, p.en)}</span></span>${p.desc ? `<p>${esc(p.desc)}</p>` : ''}` +
      (live ? '' : `<button class="ghost" id="gWatch">Watch ${esc(ch.name)} now</button>`);
    $('#gWatch')?.addEventListener('click', () => openItem(ch));
    if (live) openItem(ch);
    return;
  }
  if (e.target.closest('.g-ch')) openItem(ch);
};
// drag the edge of the channel column (in the guide header) to widen names
(() => {
  const set = w => { CH = Math.round(Math.min(600, Math.max(140, w))); document.documentElement.style.setProperty('--gch', CH + 'px'); };
  $('#gInner').addEventListener('pointerdown', e => {
    const h = e.target.closest('.g-chresize'); if (!h || e.button !== 0) return;
    e.preventDefault(); e.stopPropagation(); h.setPointerCapture(e.pointerId); document.body.classList.add('resizing');
    const x0 = e.clientX, w0 = CH, sl = $('#gScroll').scrollLeft, t0 = gStart + (sl / PPM) * 60;
    h.onpointermove = ev => set(w0 + ev.clientX - x0);
    h.onpointerup = h.onlostpointercapture = () => {
      h.onpointermove = h.onpointerup = h.onlostpointercapture = null; document.body.classList.remove('resizing');
      store.set('guideCh', CH); renderGuide(); $('#gScroll').scrollLeft = Math.max(0, (t0 - gStart) / 60 * PPM);
    };
  });
  $('#gInner').addEventListener('dblclick', e => { if (e.target.closest('.g-chresize')) { set(260); store.set('guideCh', CH); renderGuide(); } });
})();
$('#gNow').onclick = () => { $('#gScroll').scrollTo({ left: Math.max(0, gx(Date.now() / 1000) - CH - 30 * PPM), behavior: 'smooth' }); };

/* ---------- Events ---------- */
document.querySelectorAll('.rail-btn[data-sec]').forEach(b => b.onclick = () => setSection(b.dataset.sec));
$('#catList').onclick = e => {
  const li = e.target.closest('li[data-id]'); if (!li) return;
  S.catId = li.dataset.id || null; S.shown = 200;
  document.querySelectorAll('#catList li').forEach(x => x.classList.toggle('on', x === li));
  renderItems();
};
$('#catSearch').oninput = () => { if (S.section !== 'fav' && S.section !== 'recent') renderCats(); };
let st; $('#itemSearch').oninput = () => { clearTimeout(st); st = setTimeout(() => { S.shown = 200; S.allProgs = false; renderItems(); }, 250); };
$('#itemList').onclick = e => {
  const fr = e.target.closest('.ev-row');
  if (fr) { const [a, b] = fr.dataset.fx.split(':'); const w = S.fixView?.[a]?.where[b]; if (w) openItem({ ...w.ch, kind: 'live' }); return; }
  const li = e.target.closest('li'); if (!li || li.classList.contains('ev-card') || li.classList.contains('ev-head')) return;
  if (li.dataset.allprogs) { S.allProgs = true; keepScroll(renderItems); return; }
  if (li.dataset.more) { S.shown += 500; renderItems(); return; }
  if (li.dataset.allcats) { S.catId = null; renderCats(); renderItems(); return; }
  if (li.dataset.prog) { const p = S.progView?.[li.dataset.prog]; if (p) openProg(p); return; }
  if (li.dataset.ev) { const it = S.view[li.dataset.ev]; if (it) openItem(it); return; }
  const it = S.view[li.dataset.idx]; if (it) openItem(it);
};
$('#btnFav').onclick = () => { const c = S.current; if (c) toggleFav(favData(c)); };

/* right-click menu on channels / films / series */
const ctx = document.createElement('div'); ctx.className = 'ctx'; ctx.hidden = true; document.body.appendChild(ctx);
const hideCtx = () => { ctx.hidden = true; };
async function itemMenu(e, it, inList) {
  e.preventDefault(); e.stopPropagation();
  const items = [];
  if (inList) items.push({ id: 'play', label: it.kind === 'live' ? 'Play' : 'Open' });
  items.push({ id: 'fav', label: isFav(it) ? 'Remove from favourites' : 'Add to favourites' });
  if (S.section === 'recent' && inList) items.push({ id: 'rec', label: 'Remove from recently watched' });
  let a = null;
  if (window.native?.menu) { try { a = await window.native.menu(items); } catch (err) { window.native.log?.('menu: ' + err.message); } }
  else {                                          // fallback: in-page menu
    ctx.innerHTML = items.map(i => `<button data-a="${i.id}">${esc(i.label)}</button>`).join('');
    ctx.hidden = false;
    ctx.style.left = Math.min(e.clientX, innerWidth - ctx.offsetWidth - 6) + 'px';
    ctx.style.top = Math.min(e.clientY, innerHeight - ctx.offsetHeight - 6) + 'px';
    a = await new Promise(res => { ctx.onclick = ev => res(ev.target.closest('button')?.dataset.a); });
    hideCtx();
  }
  if (a === 'play') openItem(it);
  if (a === 'fav') toggleFav(favData(it));
  if (a === 'rec') { store.set(recKey(), store.get(recKey(), []).filter(x => !(x.kind === it.kind && x.id === it.id))); keepScroll(renderItems); }
}
// right-click a channel / film / series in the list
document.addEventListener('contextmenu', e => {
  if (!S.profile) return;
  const li = e.target.closest?.('#itemList li[data-idx]');
  if (li) { const it = S.view[+li.dataset.idx]; if (it) itemMenu(e, it, true); return; }
  // right-click the player or title for whatever is playing
  if (S.current && e.target.closest?.('#playerWrap, .np-head')) { const c = S.current; itemMenu(e, c.parent || c, false); }
});
document.addEventListener('pointerdown', e => { if (!ctx.contains(e.target)) hideCtx(); }, true);
document.addEventListener('keydown', e => { if (e.key === 'Escape') hideCtx(); });
$('#itemList').addEventListener('scroll', hideCtx);
window.addEventListener('blur', hideCtx);
window.addEventListener('resize', hideCtx);
$('#btnLive').onclick = () => {
  if (hls && hls.liveSyncPosition) { video.currentTime = hls.liveSyncPosition; }
  else { const b = video.buffered; if (b.length) video.currentTime = Math.max(video.currentTime, b.end(b.length - 1) - 0.5); }
  video.playbackRate = 1; video.play().catch(() => {});
};
$('#btnFull').onclick = () => toggleFull();
$('#btnExt').onclick = async () => {
  if (!S.current?.url) return;
  const c = S.current;
  // hang up our own connection first, or the provider sees two and refuses VLC (469)
  stopPlayer(); soundWarn(''); msg('Opening in VLC…');
  await new Promise(r => setTimeout(r, c.kind === 'live' ? 1500 : 200));
  const r = await window.native.openExternal(c.url, c.title, S.settings.player);
  if (!r.ok) { msg(r.error, true); return; }
  msg(`${r.installed ? 'VLC installed. ' : ''}Playing in ${/vlc/i.test(r.player) ? 'VLC' : r.player} – pick a channel here to watch in StarkTV again.`);
};
window.native?.onPlayerStatus?.(t => msg(t));
document.addEventListener('keydown', e => {
  if (S.profile && ((e.ctrlKey && (e.key === 'f' || e.key === 'F')) || (e.key === '/' && !e.target.matches('input,select')))) {
    e.preventDefault(); if (!isSearch()) setSection('search'); else $('#itemSearch').select(); return;
  }
  if (e.target.matches('input,select')) return;
  if (e.key === 'f' || e.key === 'F') toggleFull();
  if (!TV && (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'PageDown' || e.key === 'PageUp') && S.current?.kind === 'live') {
    const i = S.view.findIndex(v => v.id === S.current.id && v.kind === 'live'); if (i < 0) return;
    const n = S.view[i + (e.key === 'ArrowDown' || e.key === 'PageDown' ? 1 : -1)]; if (n) { e.preventDefault(); openItem(n); }
  }
});

/* ---------- TV remote hooks (called by the Android app) ---------- */
if (TV) {
  window.__tvZap = d => {                          // channel up/down while watching full screen
    if (S.current?.kind !== 'live') return;
    const i = S.view.findIndex(v => v.id === S.current.id && v.kind === 'live'); if (i < 0) return;
    const n = S.view[i + d]; if (n) openItem(n);
  };
  window.__tvAfterFull = () => {                   // back from full screen: put the focus on what's playing
    const el = document.querySelector('#gInner .g-row.on .g-ch') || document.querySelector('#itemList li.on') || document.querySelector('.rail-btn.on');
    el?.focus(); el?.scrollIntoView({ block: 'center', inline: 'nearest' });
  };
  window.__tvBack = () => {
    const dlg = document.querySelector('dialog[open]'); if (dlg) { dlg.close(); return true; }
    if (!ctx.hidden) { hideCtx(); return true; }
    const a = document.activeElement;
    if (a && a.matches('input, select')) { a.blur(); window.__tvFocusDefault?.(); return true; }
    if (!S.profile) return false;
    if (S.section !== 'guide') { setSection('guide'); setTimeout(() => window.__tvFocusDefault?.(), 50); return true; }
    if (S.engineNow === 'vlc' && S.current) { stopPlayer(); msg('Pick a channel to start watching'); return true; }
    return false;
  };
  window.__tvMenu = () => {                        // Menu button: favourites etc. for the focused channel
    const a = document.activeElement; if (!a) return;
    let it = null;
    if (a.matches('#itemList li[data-idx]')) it = S.view[+a.dataset.idx];
    else if (a.closest('.g-row')) it = S.view[+a.closest('.g-row').dataset.i];
    else if (S.current) it = S.current.parent || S.current;
    if (!it) return;
    const r = a.getBoundingClientRect();
    itemMenu({ preventDefault() {}, stopPropagation() {}, clientX: r.left + 40, clientY: r.top + r.height / 2 }, it, true)
      .then(() => a.focus());
    setTimeout(() => (ctx.querySelector('[data-a="fav"]') || ctx.querySelector('button'))?.focus(), 30);   // lands on Add to favourites
  };
  window.__tvInfo = () => {};

  /* ---------- Info banner over full-screen live TV (OK button) ---------- */
  const OSD = { on: false, hideT: 0, poll: 0, epg: null, epgFor: null, sel: 1 };   // sel: 0 ⏪, 1 play/pause, 2 ⏩
  const nowS = () => Date.now() / 1000;
  const st = () => { try { return JSON.parse(window.AndroidBridge.refreshStatus ? window.AndroidBridge.refreshStatus() : window.AndroidBridge.status()); } catch { return {}; } };
  const behindTxt = ms => { const s = Math.max(0, Math.round(ms / 1000)); return s < 60 ? `${s} s` : `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
  const dur = s => { s = Math.max(0, Math.round(s / 60)); return s >= 60 ? `${Math.floor(s / 60)}h ${String(s % 60).padStart(2, '0')}m` : `${s}m`; };
  window.__tvFullMode = on => {
    document.documentElement.classList.toggle('tv-full', !!on);
    if (!on) osdHide();
  };
  window.__osdShow = () => osdShow();
  window.__osdBack = () => { if (OSD.on) { osdHide(); return true; } return false; };
  // remote while watching: OK shows the banner (OK again = pause/play), ◀ ▶ jump 10 s; ⏪ ⏩ ▶❚❚ are handled by the app
  window.__osdKey = k => {
    const B = window.AndroidBridge;
    if (k === 'left' || k === 'right') { B.jumpBy(k === 'left' ? -10000 : 10000); setTimeout(osdShow, 150); return; }
    if (k !== 'ok') return;
    if (!OSD.on) osdShow(); else { B.togglePause(); setTimeout(osdShow, 150); }
  };
  async function osdEpg() {
    const ch = S.current; if (!ch || ch.kind !== 'live') return [];
    if (OSD.epgFor === ch.id && OSD.epg) return OSD.epg;
    OSD.epgFor = ch.id; OSD.epg = [];
    try { OSD.epg = await fetchEpg(ch.id); } catch {}
    return OSD.epg;
  }
  function osdShow() {
    OSD.on = true; $('#osd').hidden = false;
    osdRender();
    clearInterval(OSD.poll); OSD.poll = setInterval(osdRender, 500);
    osdArm();
  }
  function osdArm() {
    clearTimeout(OSD.hideT);
    const t = +S.settings.osdTime;
    if (t > 0) OSD.hideT = setTimeout(() => { const s = st(); if (s.paused || s.trick) { osdArm(); return; } osdHide(); }, t * 1000);
  }
  function osdHide() { OSD.on = false; clearInterval(OSD.poll); clearTimeout(OSD.hideT); const o = $('#osd'); if (o) o.hidden = true; }
  async function osdRender() {
    if (!OSD.on) return;
    const s = st(), ch = S.current; if (!ch) return;
    const list = await osdEpg();
    const behind = s.behind > 0 ? s.behind : 0;
    const watching = nowS() - behind / 1000;                    // the moment on screen
    const prog = list.find(p => p.st <= watching && watching < p.en) || null;
    const next = prog ? list.find(p => p.st >= prog.en) : list.find(p => p.st > watching);
    const pct = t => prog ? Math.max(0, Math.min(100, (t - prog.st) / (prog.en - prog.st) * 100)) : 0;
    const head = pct(watching), live = pct(nowS());
    const atLive = behind <= (s.delay || 0) + 2500 && !s.paused && !s.trick;
    const tag = !s.timeshift ? 'LIVE' : atLive ? `${behindTxt(behind)} behind live` : `${behindTxt(behind)} behind live`;
    $('#osd').innerHTML =
      (s.trick ? `<div class="osd-trick">${s.trick < 0 ? '⏪' : '⏩'} <span class="sp">×${Math.abs(s.trick)}</span><span class="ts">−${behindTxt(behind)} behind live</span></div>`
        : s.paused ? `<div class="osd-trick">❚❚ <span class="ts">Paused · ${behindTxt(behind)} behind live</span></div>` : '') +
      `<div class="osd-banner"><div class="osd-in">
        <div class="osd-r1"><div class="osd-chan"><span class="no">${esc(ch.num ?? '')}</span>${ch.icon ? `<img src="${esc(ch.icon)}" onerror="this.style.visibility='hidden'">` : ''}</div>
          <div class="osd-np"><span class="tag">NOW</span><span class="time">${prog ? `${hhmm(prog.st)} – ${hhmm(prog.en)}` : esc(ch.name)}</span>
            <div class="t">${esc(prog ? prog.title : ch.name)}</div></div>
          <div class="osd-clock">${hhmm(nowS())}</div></div>
        ${prog ? `<div class="osd-prog"><span>${hhmm(prog.st)}</span><div class="bar"><div class="w" style="width:${head}%"></div><div class="gap" style="left:${head}%;width:${Math.max(0, live - head)}%"></div><div class="live" style="left:${live}%"></div><div class="head" style="left:${head}%"></div></div><span>${hhmm(prog.en)}</span></div>
          <div class="osd-sub">${dur(watching - prog.st)} in · ${dur(prog.en - watching)} left</div>` : ''}
        <div class="osd-r3"><span class="next">${next ? `NEXT<b>${hhmm(next.st)}</b>${esc(next.title)}` : ''}</span>
          <div class="right"><span class="pill ${!s.timeshift ? 'live' : 'delay'}">${tag}</span></div></div>
      </div></div>`;
  }
  window.__tvFavCurrent = () => {                  // Menu while watching full screen: star / unstar this channel
    const c = S.current; if (!c) return;
    const it = c.parent || c, was = isFav(it);
    toggleFav(favData(it));
    window.AndroidBridge.toast?.(was ? `Removed ${it.name} from favourites` : `★ Added ${it.name} to favourites`);
  };
}

/* settings */
$('#btnSettings').onclick = () => {
  $('#setFormat').value = S.settings.format; $('#setBuffer').value = S.settings.buffer; $('#setPlayer').value = S.settings.player; $('#setAdult').checked = S.settings.hideAdult; $('#setResume').checked = S.settings.resume;
  $('#setEngine').value = S.settings.engine || 'auto';
  $('#setDelay').value = String(S.settings.liveDelay ?? 15); $('#setRewind').value = String(S.settings.rewindMin ?? 30); $('#setOsd').value = String(S.settings.osdTime ?? 5);
  window.native?.vlc?.visible(false);              // the VLC picture is a separate window – keep it out of the dialog's way
  $('#settings').showModal();
};
$('#setSave').onclick = () => {
  S.settings = { format: $('#setFormat').value, buffer: $('#setBuffer').value, player: $('#setPlayer').value.trim(), hideAdult: $('#setAdult').checked, resume: $('#setResume').checked, engine: $('#setEngine').value,
    liveDelay: +$('#setDelay').value, rewindMin: +$('#setRewind').value, osdTime: +$('#setOsd').value };
  store.set('settings', S.settings);
  if (S.section !== 'fav' && S.section !== 'recent') { renderCats(); renderItems(); }
};

$('#settings').addEventListener('close', () => { if (S.engineNow === 'vlc') window.native?.vlc?.visible(true); });

/* ---------- Resizable columns ---------- */
const COLS = { rail: [190, 120, 360], cats: [230, 140, 700], items: [320, 200, 1000] };
const colW = store.get('cols', {});
function applyCols() { for (const k in COLS) document.documentElement.style.setProperty('--w-' + k, (colW[k] || COLS[k][0]) + 'px'); }
applyCols();
document.querySelectorAll('.resizer').forEach(h => {
  const k = h.dataset.col, col = h.parentElement;
  h.onpointerdown = e => {
    if (e.button !== 0) return;
    e.preventDefault(); h.setPointerCapture(e.pointerId); h.classList.add('drag'); document.body.classList.add('resizing');
    const x0 = e.clientX, w0 = col.getBoundingClientRect().width;
    const others = Object.keys(COLS).filter(x => x !== k).reduce((t, x) => t + (colW[x] || COLS[x][0]), 0);
    const [, min, maxW] = COLS[k], max = Math.max(min, Math.min(maxW, window.innerWidth - others - 380)); // keep the player usable
    h.onpointermove = ev => { colW[k] = Math.round(Math.min(max, Math.max(min, w0 + ev.clientX - x0))); applyCols(); };
    h.onpointerup = h.onlostpointercapture = () => {
      h.onpointermove = h.onpointerup = h.onlostpointercapture = null;
      h.classList.remove('drag'); document.body.classList.remove('resizing'); store.set('cols', colW);
    };
  };
  h.ondblclick = () => { delete colW[k]; applyCols(); store.set('cols', colW); };
});

/* ---------- Login screen ---------- */
let mode = 'xtream', editId = null;
function setMode(m) {
  mode = m;
  document.querySelectorAll('.seg-btn').forEach(x => x.classList.toggle('on', x.dataset.mode === m));
  document.querySelector('.xt').hidden = m !== 'xtream'; document.querySelector('.m3').hidden = m !== 'm3u';
}
document.querySelectorAll('.seg-btn').forEach(b => b.onclick = () => setMode(b.dataset.mode));
function renderSaved() {
  const d = prof.load();
  $('#saved').innerHTML = d.profiles.map((p, i) => `<div class="saved-row"><b>${esc(p.name)}</b><span>${p.type === 'xtream' ? 'Xtream' : 'M3U'}${p.id === d.last ? ' · last used' : ''}</span><button class="primary" data-go="${i}">Open</button><button class="ghost" data-edit="${i}">Edit</button><button class="ghost" data-del="${i}">Remove</button></div>`).join('');
  $('#autoWrap').hidden = !d.profiles.length;
  $('#autoConn').checked = d.autoConnect !== false;
}
$('#autoConn').onchange = e => { const d = prof.load(); d.autoConnect = e.target.checked; prof.save(d); };
function resetForm() {
  editId = null; $('#addForm').reset(); $('#btnAdd').textContent = 'Add and connect'; $('#btnCancelEdit').hidden = true;
}
$('#btnCancelEdit').onclick = resetForm;
async function openProfile(p, btn) {
  const d = prof.load(); d.last = p.id; prof.save(d);
  if (btn) { btn.disabled = true; btn.textContent = 'Connecting…'; }
  $('#loginErr').hidden = true;
  try { await connect(p); }
  catch (err) { showLogin(); showErr(err); renderSaved(); }
}
$('#saved').onclick = async e => {
  const d = prof.load(), t = e.target.dataset;
  if (t.del) {
    const [gone] = d.profiles.splice(+t.del, 1);
    if (gone && d.last === gone.id) d.last = null;
    prof.save(d); renderSaved(); return;
  }
  if (t.edit) {
    const p = d.profiles[+t.edit], f = $('#addForm');
    editId = p.id; setMode(p.type);
    const el = n => f.elements.namedItem(n);
    el('name').value = p.name || ''; el('server').value = p.server || ''; el('user').value = p.user || ''; el('pass').value = p.pass || ''; el('m3u').value = p.m3u || '';
    $('#btnAdd').textContent = 'Save and connect'; $('#btnCancelEdit').hidden = false; f.name.focus(); return;
  }
  if (t.go) openProfile(d.profiles[+t.go], e.target);
};
function showErr(err) { const el = $('#loginErr'); el.textContent = err.message.includes('Failed to fetch') ? 'Couldn’t reach the server. Check the URL (include http:// and the port).' : err.message; el.hidden = false; }
const sameLogin = (a, b) => a.type === b.type && (a.type === 'xtream' ? base(a).toLowerCase() === base(b).toLowerCase() && a.user === b.user : a.m3u === b.m3u);
$('#addForm').onsubmit = async e => {
  e.preventDefault();
  const f = new FormData(e.target), btn = $('#btnAdd');
  const p = { id: editId || Date.now().toString(36), name: f.get('name').trim(), type: mode };
  if (mode === 'xtream') { p.server = f.get('server').trim(); p.user = f.get('user').trim(); p.pass = f.get('pass');
    if (!p.server || !p.user) return showErr(new Error('Fill in the server URL and username.'));
    if (!/^https?:\/\//i.test(p.server)) p.server = 'http://' + p.server; }
  else { p.m3u = f.get('m3u').trim(); if (!p.m3u) return showErr(new Error('Paste the playlist URL.')); }
  // save straight away so the details are kept even if the server is down right now
  const d = prof.load();
  const i = d.profiles.findIndex(x => x.id === p.id || sameLogin(x, p));
  if (i >= 0) { p.id = d.profiles[i].id; d.profiles[i] = p; } else d.profiles.push(p);   // keep id so favourites survive
  d.last = p.id; prof.save(d); renderSaved();
  btn.disabled = true; btn.textContent = 'Connecting…'; $('#loginErr').hidden = true;
  try { await connect(p); resetForm(); }
  catch (err) { showErr(err); btn.textContent = editId ? 'Save and connect' : 'Add and connect'; editId = p.id; $('#btnCancelEdit').hidden = false; }
  finally { btn.disabled = false; }
};
$('#btnSwitch').onclick = () => { stopPlayer(); S.current = null; msg('Pick a channel to start watching'); showLogin(); renderSaved(); };

/* ---------- Start-up: reconnect to the last playlist ---------- */
(function boot() {
  const d = prof.load(); renderSaved();
  const i = d.profiles.findIndex(x => x.id === d.last);
  if (d.autoConnect !== false && i >= 0) openProfile(d.profiles[i], $(`#saved [data-go="${i}"]`));   // splash stays up while it connects
  else showLogin();
})();
