# StarkTV changelog

Fire TV builds are numbered `version.build` (e.g. 2.9.14 = version 2.9, GitHub build 14).
The PC app (Windows) shares the same interface code; PC-only changes are marked **PC**.

## 3.0 (later builds) — Faster channels and full screen
- Channels start faster: the picture appears after ~0.5 s of video instead of 2.5 s, the first recording chunks are
  shorter, and keyframes are found in the picture data itself – channels that don't flag them (previously several
  seconds slower) now start as quickly as the rest. Long gaps between keyframes no longer hold the stream up.
- Full screen is near-instant: the video now always sits underneath the page, so going full screen just stretches it
  instead of re-stacking and redrawing everything (which took 1–2 s on a Fire Stick).
- "Connecting…" / error messages now show over the picture area on the TV.
- Fixed: with no last channel to resume, the first channel you picked jumped straight to full screen.

## 3.0 — Phones too
- The same app now works on Android phones and tablets as well as Fire TV / Android TV – it detects which it's on.
- On a phone:
  - tap the small picture (or a channel twice) for full screen; the back button returns to the guide,
  - full screen: tap for the info banner with ⏪ ❚❚ ⏩ and ✕ (exit) buttons; double-tap the left/right side to jump
    10 s; swipe up/down to change channel,
  - live delay, 30-minute pause/rewind and the banner work the same as on the TV.
- TV / Fire TV unchanged (remote only, no on-screen buttons).
- Install on a phone: open the latest-release link in the phone's browser and allow it to install apps.

## 2.9 (later builds) — Remote-only rewind / fast-forward
- On-screen ⏪ ❚❚ ⏩ / LIVE buttons removed from the banner – the remote's own buttons do it:
  ⏪ ⏩ rewind / fast-forward (×2 → ×6 → ×12 → ×30), ▶❚❚ pause/play (hold = back to live), ◀ ▶ jump 10 s,
  OK shows the banner (OK again = pause/play). The banner and the centre box show how far behind live you are,
  updating as you rewind or fast-forward.
- Fixed: rewind / fast-forward kept snapping back to the nearest keyframe, so slow speeds barely moved or jumped
  about. They now move steadily.
- Pause & rewind now goes up to **30 minutes** (new default). Uses about 1.4 GB of storage for an HD channel; the
  recording automatically gives space back if the Stick drops below ~400 MB free.

## 2.9 — Live delay, pause, rewind & info banner (Fire TV)
- **Live delay (stops buffering):** live channels play a little behind live and keep that in reserve, so short drops in
  the stream no longer freeze the picture or skip ahead. Builds up by playing at 97 % speed – no wait when changing
  channel. Settings → *Live delay*: Off / 10 / 15 (default) / 20 / 30 s.
- **Pause, rewind and fast-forward live TV:** the channel is recorded to a rolling buffer while you watch.
  Settings → *Pause & rewind up to*: 3 / 5 (default) / 10 / 20 minutes.
  - ⏪ ⏩ on the remote: ×2 → ×6 → ×12 → ×30 per press; ▶❚❚ resumes. Fast-forward stops at live.
  - ◀ ▶ while watching: jump back / forward 10 seconds.
  - ▶❚❚: pause / play. Hold ▶❚❚: jump back to live.
- **Info banner (OK button):** set-top-box style banner along the bottom – channel number and logo, NOW programme with
  start/end times and a progress bar, where you are vs. live, time left, the clock, NEXT programme, and how far behind
  live you are. Settings → *Info banner*: hide after 5 s / 10 s / stay until Back.
- Leaving the app (Home) now releases the provider connection; coming back starts the channel again at live.
- Channels that stop sending show a clear message instead of an endless spinner.

## 2.8 — New logo
- Orange play-triangle "S" logo: Fire TV home-screen banner, app icon, sidebar, login and start-up screens.
- **PC:** window/taskbar icon, `starktv.ico` for shortcuts.
- Fire TV: icon/banner renamed so the home screen drops its cached copy of the old logo.

## 2.7 — Straight into TV
- Saved login: a short start-up screen instead of the login page flashing up; the Fire TV opens the last channel full
  screen. The login page only appears with no saved playlist, a failed connection, or *Switch playlist*.

## 2.6 — Fire TV app
- New Android TV / Fire TV app built on GitHub (Media3 player with FFmpeg audio, so Dolby/MP2 channels have sound).
- Remote navigation: arrows, OK, Back; guide rows don't jump to the categories at the end of the list; holding the
  arrows scrolls smoothly; left/right stay on the same channel row.
- Picking a channel plays it in the small window; OK on it again goes full screen. Up/Down change channel full screen.
- Favourites: hold OK (or ☰) on a channel; ☰ while watching stars the current channel.
- Version shown in full in the sidebar.
- **PC:** VLC can play inside StarkTV (Settings → Player: Automatic / Always VLC / Built-in only); automatic mode
  switches to VLC for channels with no sound. "Open in VLC" installs VLC if it's missing. Guide programme titles stay
  readable when a programme started off-screen.

## 2.5 — PC
- Renamed **StarkTV** (was Tidewatch IPTV); version in the window title and exe name.
- No-sound check with an Unmute / Open-in-VLC prompt; clearer handling of provider error 469 (connection limit).

## 2.3 – 2.4
- **Search** is its own section (Ctrl+F or /); Live TV merged into the TV guide.
- Smarter search: topics (*running* → marathons, athletics…), nicknames (*spurs*, *man utd*), typo tolerance, any word order,
  programme categories.
- Live sport without two sides (marathons, races, golf) gets its own card.

## 2.0 – 2.2
- Match & event cards: real kick-off times from ESPN (football, rugby, UFC), cricket from the guide, which channels show
  it and when TV coverage starts. Repeats/highlights are never treated as the live match; LIVE / REPEAT tags.
- Event-channel times read correctly (US Eastern, month names), ended events no longer badged.

## 1.8 – 1.9
- Programme search across the whole guide (not just channel names in one category), start times and countdowns.

## 1.7
- Original Tidewatch IPTV (PC): Xtream/M3U playlists, TV guide, favourites, recently watched, VLC hand-off.
